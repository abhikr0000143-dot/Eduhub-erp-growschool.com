package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Frosted Glass Palette (Modern Premium Aesthetic)
val PrimaryIndigo = Color(0xFF4F46E5)      // Premium Indigo
val SecondaryBlue = Color(0xFF3B82F6)      // Sleek Sky Blue
val TertiaryEmerald = Color(0xFF10B981)    // Accent Emerald
val DarkPrimary = Color(0xFF818CF8)        // Soft Indigo for Dark Theme

private val DarkColorScheme =
  darkColorScheme(
    primary = DarkPrimary,
    secondary = Color(0xFF60A5FA),
    tertiary = Color(0xFF34D399),
    background = Color(0xFF0F172A),
    surface = Color(0x331E293B), // Dark Glass base (translucent)
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0x26FFFFFF),
    outline = Color(0x33FFFFFF)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = PrimaryIndigo,
    secondary = SecondaryBlue,
    tertiary = TertiaryEmerald,
    background = Color.Transparent, // Allows back mesh blobs to render through scaffold
    surface = Color(0x73FFFFFF),     // Perfect translucent glass: 45% white
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
    primaryContainer = Color(0x334F46E5), // Soft translucent indigo container
    secondaryContainer = Color(0x333B82F6), // Soft translucent blue container
    surfaceVariant = Color(0x2BFFFFFF),    // ultra-sheer glass
    outline = Color(0x99FFFFFF)            // crisp white glass border
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disable dynamic color by default to preserve hand-packaged premium Frosted Glass styles
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

