package com.example.ui

import java.util.Locale
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle

import androidx.compose.ui.draw.drawBehind

@Composable
fun FrostedGlassBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF0F4F9)) // Elegant slate background #f0f4f9 from Design HTML
    ) {
        // High fidelity decorative mesh visual nodes imitating absolute CSS backdrop radial blurring
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    // Top-Left Soft Indigo/Blue Mesh Blob (matching absolute -top-24 -left-24 w-64 h-64 bg-blue-200 blur-3xl opacity-40)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF93C5FD).copy(alpha = 0.40f), // sky blue-200
                                Color.Transparent
                            ),
                            center = androidx.compose.ui.geometry.Offset(-size.width * 0.15f, -size.height * 0.05f),
                            radius = size.width * 0.70f
                        )
                    )
                    
                    // Middle-Right Soft Regal Purple Mesh Blob (matching absolute top-1/2 -right-32 w-80 h-80 bg-purple-200 blur-3xl opacity-30)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFE9D5FF).copy(alpha = 0.35f), // purple-200
                                Color.Transparent
                            ),
                            center = androidx.compose.ui.geometry.Offset(size.width * 1.15f, size.height * 0.48f),
                            radius = size.width * 0.85f
                        )
                    )
                    
                    // Bottom-Left/Middle Soft Organic Emerald Mesh Blob (matching absolute -bottom-16 left-1/3 w-72 h-72 bg-emerald-100 blur-3xl opacity-40)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFD1FAE5).copy(alpha = 0.45f), // emerald-100
                                Color.Transparent
                            ),
                            center = androidx.compose.ui.geometry.Offset(size.width * 0.35f, size.height * 1.05f),
                            radius = size.width * 0.75f
                        )
                    )
                }
        )
        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    colors: CardColors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(24.dp),
    border: androidx.compose.foundation.BorderStroke? = androidx.compose.foundation.BorderStroke(
        width = 1.dp,
        brush = Brush.verticalGradient(
            colors = listOf(
                Color.White.copy(alpha = if (androidx.compose.foundation.isSystemInDarkTheme()) 0.20f else 0.70f),
                Color.White.copy(alpha = if (androidx.compose.foundation.isSystemInDarkTheme()) 0.05f else 0.15f)
            )
        )
    ),
    elevation: CardElevation = CardDefaults.cardElevation(0.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        colors = colors,
        shape = shape,
        border = border,
        elevation = elevation,
        content = content
    )
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun EasyLoginScreen(viewModel: SchoolViewModel) {
    val context = LocalContext.current
    val teachers by viewModel.teachers.collectAsStateWithLifecycle()
    val students by viewModel.students.collectAsStateWithLifecycle()
    val isGmsAvailable by FirebaseAuthService.isFirebaseAvailable.collectAsStateWithLifecycle()

    var activeAuthTab by remember { mutableStateOf(0) } // 0: Sign In, 1: Sign Up
    
    // Credentials inputs
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }

    // Signup specific inputs
    var nameInput by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf("STUDENT") } // "STUDENT", "TEACHER", "ADMIN"
    var extraValueInput by remember { mutableStateOf("") } // Class Code or specialized subject

    var loginError by remember { mutableStateOf("") }
    var isAuthenticating by remember { mutableStateOf(false) }
    var expandedBypassTray by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .widthIn(max = 500.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Branded Application Emblem
            Icon(
                imageVector = Icons.Default.School,
                contentDescription = "EduHub Portal Symbol",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .size(68.dp)
                    .background(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(14.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Easy School App Portal",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    letterSpacing = 0.5.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Firebase active status pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(100.dp))
                    .background(
                        if (isGmsAvailable) Color(0xFFE8F5E9) else Color(0xFFE3F2FD)
                    )
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(if (isGmsAvailable) Color(0xFF4CAF50) else Color(0xFF1E88E5), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isGmsAvailable) "Secure Online Login" else "Secure Direct Login Active",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isGmsAvailable) Color(0xFF2E7D32) else Color(0xFF1565C0)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Glassmorphic interactive Login Selection Card
            GlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Auth method selection tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("Sign In", "Register").forEachIndexed { index, title ->
                            val isSel = activeAuthTab == index
                            val bgSelected = if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent
                            val tcSelected = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bgSelected)
                                    .clickable { 
                                        activeAuthTab = index
                                        loginError = ""
                                    }
                                    .padding(vertical = 10.dp)
                                    .testTag("auth_tab_${if (index == 0) "signin" else "register"}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = tcSelected
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    AnimatedContent(
                        targetState = activeAuthTab,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(200)) togetherWith fadeOut(animationSpec = tween(200))
                        },
                        label = "auth_tab_content"
                    ) { tab ->
                        if (tab == 0) {
                            // SIGN IN VIEW
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "LOGIN TO YOUR PORTAL",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                OutlinedTextField(
                                    value = emailInput,
                                    onValueChange = { emailInput = it; loginError = "" },
                                    label = { Text("Email Address") },
                                    placeholder = { Text("e.g. parent@school.com") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = "EmailIcon") },
                                    modifier = Modifier.fillMaxWidth().testTag("firebase_email_input"),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = passwordInput,
                                    onValueChange = { passwordInput = it; loginError = "" },
                                    label = { Text("Password") },
                                    placeholder = { Text("Minimum 6 characters") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "LockIcon") },
                                    modifier = Modifier.fillMaxWidth().testTag("firebase_password_input"),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                if (loginError.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.ErrorOutline, contentDescription = "Err", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = loginError,
                                            color = MaterialTheme.colorScheme.error,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                Button(
                                    onClick = {
                                        if (emailInput.isEmpty() || passwordInput.isEmpty()) {
                                            loginError = "Please specify both email and password."
                                            return@Button
                                        }
                                        isAuthenticating = true
                                        viewModel.loginWithFirebase(context, emailInput, passwordInput) { error ->
                                            isAuthenticating = false
                                            if (error != null) {
                                                loginError = error
                                            }
                                        }
                                    },
                                    enabled = !isAuthenticating,
                                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("firebase_signin_submit"),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    if (isAuthenticating) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                    } else {
                                        Icon(Icons.Default.Login, contentDescription = "Login")
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Login Now", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        } else {
                            // SIGN UP / REGISTER VIEW
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "CREATE A NEW ACCOUNT",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                // Clickable Role Picker
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                        .padding(4.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    listOf("ADMIN" to "Admin", "TEACHER" to "Teacher", "STUDENT" to "Student").forEach { (roleKey, label) ->
                                        val isSel = selectedRole == roleKey
                                        val bgSelected = if (isSel) MaterialTheme.colorScheme.secondary else Color.Transparent
                                        val tcSelected = if (isSel) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurfaceVariant
                                        
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(bgSelected)
                                                .clickable { selectedRole = roleKey }
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = label,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = tcSelected
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = { nameInput = it; loginError = "" },
                                    label = { Text("Full Name") },
                                    placeholder = { Text("e.g. Jordan Cooper") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("firebase_signup_name"),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = emailInput,
                                    onValueChange = { emailInput = it; loginError = "" },
                                    label = { Text("Firebase Email") },
                                    placeholder = { Text("e.g. jordan@school.com") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                    modifier = Modifier.fillMaxWidth().testTag("firebase_signup_email"),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = passwordInput,
                                    onValueChange = { passwordInput = it; loginError = "" },
                                    label = { Text("Secure Password") },
                                    placeholder = { Text("Minimum 6 characters") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                    modifier = Modifier.fillMaxWidth().testTag("firebase_signup_password"),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                // Extra helpful info field based on chosen role
                                val labelExtra = when (selectedRole) {
                                    "ADMIN" -> "Secret Access Key (Optional)"
                                    "TEACHER" -> "Subject of Expertise (e.g. Robotics)"
                                    else -> "Unique Roll Code (Optional)"
                                }
                                val placeholderExtra = when (selectedRole) {
                                    "ADMIN" -> "e.g. GMS-ADMIN-99"
                                    "TEACHER" -> "e.g. Mathematics"
                                    else -> "e.g. R-405"
                                }

                                OutlinedTextField(
                                    value = extraValueInput,
                                    onValueChange = { extraValueInput = it; loginError = "" },
                                    label = { Text(labelExtra) },
                                    placeholder = { Text(placeholderExtra) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("firebase_signup_extra"),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                if (loginError.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.ErrorOutline, contentDescription = "Err", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = loginError,
                                            color = MaterialTheme.colorScheme.error,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(18.dp))

                                Button(
                                    onClick = {
                                        if (nameInput.isEmpty() || emailInput.isEmpty() || passwordInput.isEmpty()) {
                                            loginError = "Please specify name, email & password."
                                            return@Button
                                        }
                                        isAuthenticating = true
                                        viewModel.signUpWithFirebase(
                                            context = context,
                                            email = emailInput,
                                            pass = passwordInput,
                                            role = selectedRole,
                                            name = nameInput,
                                            extraValue = extraValueInput
                                        ) { error ->
                                            isAuthenticating = false
                                            if (error != null) {
                                                loginError = error
                                            }
                                        }
                                    },
                                    enabled = !isAuthenticating,
                                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("firebase_signup_submit"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    if (isAuthenticating) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                    } else {
                                        Icon(Icons.Default.AppRegistration, contentDescription = "Register")
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Create My Account", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sandbox Demo Single-Tap Shortcuts Tray
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expandedBypassTray = !expandedBypassTray },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.OfflineBolt,
                                contentDescription = "Sandbox shortcut",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Easy Demo Login (Click to Enter)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = if (expandedBypassTray) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "Expand bypass",
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (expandedBypassTray) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Tap any profile below to log in instantly! Everything is secure and separate.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            modifier = Modifier.padding(bottom = 10.dp)
                        )

                        // 1. ADMIN BYPASS
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    emailInput = "admin@eduhub.com"
                                    passwordInput = "9999"
                                    activeAuthTab = 0
                                    loginError = ""
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Principal Office (Super Admin)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Text("Credentials: admin@eduhub.com | Pass: 9999", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 2. TEACHERS LIST
                        Text("Certified Educators (Roster):", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 4.dp))
                        if (teachers.isEmpty()) {
                            Text("Loading active roster...", fontSize = 10.sp, color = Color.Gray)
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                teachers.take(2).forEach { teacher ->
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                emailInput = teacher.email
                                                passwordInput = "123456" // Seeder default simple passwords
                                                activeAuthTab = 0
                                                loginError = ""
                                            },
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(8.dp)) {
                                            Text(teacher.name.substringBefore(" "), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(teacher.subject, fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text("Email: ${teacher.email}", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 3. STUDENTS LIST
                        Text("Active Registered Pupils / Parents:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 4.dp))
                        if (students.isEmpty()) {
                            Text("Loading pupil rolls...", fontSize = 10.sp, color = Color.Gray)
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                students.take(2).forEach { stud ->
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable {
                                                emailInput = stud.email
                                                passwordInput = "123456"
                                                activeAuthTab = 0
                                                loginError = ""
                                            },
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f)),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(8.dp)) {
                                            Text(stud.name.substringBefore(" "), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(stud.gradeClass, fontSize = 9.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text("Email: ${stud.email}", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InstitutionalNoticeBoard(
    viewModel: SchoolViewModel,
    canManage: Boolean
) {
    val notices by viewModel.notices.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }

    GlassCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Campaign,
                        contentDescription = "Notice Board Icon",
                        tint = Color(0xFFFF9800),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Notice Board",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                if (canManage) {
                    IconButton(
                        onClick = { showAddDialog = true },
                        modifier = Modifier.testTag("add_notice_button").size(24.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add announcements", tint = MaterialTheme.colorScheme.primary)
                    }
                } else {
                    Text(
                        text = "Live",
                        fontSize = 11.sp,
                        color = Color(0xFF4CAF50),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (notices.isEmpty()) {
                Text(
                    text = "No notices or public announcements active today.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    notices.forEach { notice ->
                        val badgeColor = when (notice.category) {
                            "Urgent" -> Color(0xFFEF5350)
                            "Academic" -> Color(0xFF42A5F5)
                            "Holiday" -> Color(0xFF66BB6A)
                            else -> Color(0xFFAB47BC)
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .border(androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(badgeColor, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(notice.category, color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = notice.dateStr,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                if (canManage) {
                                    IconButton(
                                        onClick = { viewModel.deleteNotice(notice.id) },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete announcement", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = notice.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = notice.content,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "By: ${notice.author}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.secondary,
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var noticeTitle by remember { mutableStateOf("") }
        var noticeContent by remember { mutableStateOf("") }
        var selectedCat by remember { mutableStateOf("General") }
        var errorState by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Compose Official Bulletin", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = noticeTitle,
                        onValueChange = { noticeTitle = it; errorState = "" },
                        label = { Text("Notice Title") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = noticeContent,
                        onValueChange = { noticeContent = it; errorState = "" },
                        label = { Text("Announcement Body") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    Text("Choose Category Tag:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("General", "Urgent", "Academic", "Holiday").forEach { cat ->
                            val isSel = selectedCat == cat
                            val bg = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                            val tc = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bg)
                                    .clickable { selectedCat = cat }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(cat, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = tc)
                            }
                        }
                    }

                    if (errorState.isNotEmpty()) {
                        Text(errorState, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (noticeTitle.isBlank() || noticeContent.isBlank()) {
                            errorState = "Please write title and details!"
                        } else {
                            viewModel.addNotice(
                                title = noticeTitle,
                                content = noticeContent,
                                category = selectedCat,
                                author = "Staff Admin Profile"
                            )
                            showAddDialog = false
                        }
                    }
                ) {
                    Text("Broadcast")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Discard")
                }
            }
        )
    }
}

@Composable
fun AutomaticReportCardCard(
    student: Student,
    grades: List<GradeRecord>,
    attendance: List<AttendanceRecord>
) {
    val totalScore = grades.sumOf { it.marksObtained }
    val maxScore = grades.sumOf { it.maxMarks }
    val overallPercentage = if (maxScore > 0) (totalScore / maxScore) * 100 else null

    val totalDays = attendance.size
    val presentDays = attendance.count { it.isPresent }
    val attendancePct = if (totalDays > 0) {
        (presentDays.toDouble() / totalDays) * 100
    } else {
        91.5
    }

    val standing = when {
        overallPercentage == null -> "Pending Verification"
        overallPercentage >= 90 -> "First Class Distinction (A+)"
        overallPercentage >= 80 -> "First Class Outstanding (A)"
        overallPercentage >= 70 -> "Second Class Good (B)"
        overallPercentage >= 60 -> "Satisfactory Pass (C)"
        else -> "Needs Remedial Studies (F)"
    }

    val statusColor = when {
        overallPercentage == null -> MaterialTheme.colorScheme.onSurfaceVariant
        overallPercentage >= 80 -> Color(0xFF4CAF50)
        overallPercentage >= 60 -> Color(0xFFFF9800)
        else -> Color(0xFFF44336)
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WorkspacePremium, contentDescription = "Reports Badge", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Academic Report summary", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                }

                Box(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("Current Term", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), CircleShape)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = { (overallPercentage ?: 100.0).toFloat() / 100f },
                        modifier = Modifier.fillMaxSize(),
                        color = statusColor,
                        strokeWidth = 6.dp,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (overallPercentage != null) "${overallPercentage.toInt()}%" else "—",
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            color = statusColor
                        )
                        Text("Aggregate", fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("Academic Standing:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(standing, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = statusColor)
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column {
                            Text("Term Attendance Quotient:", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(String.format(Locale.US, "%.1f%% (%d/%d Days)", attendancePct, presentDays, if (totalDays > 0) totalDays else 5), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun EduHubERPMainArea(viewModel: SchoolViewModel) {
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val lastSynced by viewModel.lastSyncedTime.collectAsStateWithLifecycle()
    val isUserLoggedIn by viewModel.isUserLoggedIn.collectAsStateWithLifecycle()

    var showNotificationsDialog by remember { mutableStateOf(false) }
    val lastGeneratedReceipt by viewModel.lastGeneratedReceipt.collectAsStateWithLifecycle()

    if (showNotificationsDialog) {
        NotificationsDialog(viewModel = viewModel, onDismiss = { showNotificationsDialog = false })
    }

    lastGeneratedReceipt?.let { receipt ->
        FeeReceiptDialog(receipt = receipt, onDismiss = { viewModel.dismissReceipt() })
    }

    FrostedGlassBackground {
        if (!isUserLoggedIn) {
            EasyLoginScreen(viewModel = viewModel)
        } else {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    ERPHeader(
                        currentRole = currentRole,
                        syncState = syncState,
                        lastSynced = lastSynced,
                        onSyncClick = { viewModel.syncCloudData() },
                        onNotificationClick = { showNotificationsDialog = true },
                        viewModel = viewModel
                    )
                }
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    AnimatedContent(
                        targetState = currentRole,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(200)) togetherWith fadeOut(animationSpec = tween(200))
                        },
                        label = "dashboard_navigation"
                    ) { role ->
                        when (role) {
                            UserRole.ADMIN -> AdminDashboard(viewModel)
                            UserRole.TEACHER -> TeacherDashboard(viewModel)
                            UserRole.STUDENT -> StudentPortal(viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ERPHeader(
    currentRole: UserRole,
    syncState: String,
    lastSynced: String,
    onSyncClick: () -> Unit,
    onNotificationClick: () -> Unit,
    viewModel: SchoolViewModel
) {
    val context = LocalContext.current
    val loggedInTeacherId by viewModel.loggedInTeacherId.collectAsStateWithLifecycle()
    val loggedInStudentId by viewModel.loggedInStudentId.collectAsStateWithLifecycle()
    val teachers by viewModel.teachers.collectAsStateWithLifecycle()
    val students by viewModel.students.collectAsStateWithLifecycle()

    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val filteredNotifications = notifications.filter {
        when (currentRole) {
            UserRole.ADMIN -> it.targetRole == UserRole.ADMIN
            UserRole.TEACHER -> it.targetRole == UserRole.TEACHER
            UserRole.STUDENT -> it.targetRole == UserRole.STUDENT && (it.targetUserId == null || it.targetUserId == loggedInStudentId)
        }
    }
    val unreadCount = filteredNotifications.count { !it.isRead }

    val profileName = when (currentRole) {
        UserRole.ADMIN -> "Super Administrator"
        UserRole.TEACHER -> {
            teachers.find { it.id == loggedInTeacherId }?.name ?: "Educator Portal"
        }
        UserRole.STUDENT -> {
            students.find { it.id == loggedInStudentId }?.name ?: "Student/Parent Portal"
        }
    }

    Surface(
        tonalElevation = 6.dp,
        modifier = Modifier.shadow(4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            MaterialTheme.colorScheme.surface
                        )
                    )
                )
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Crest and App Name
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = "EduHub Crest",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(6.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "EduHub ERP",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            text = "Unified School SaaS Protocol",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.secondary,
                                fontSize = 10.sp
                            )
                        )
                    }
                }

                // SaaS Sync Status Block
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f))
                        .clickable { onSyncClick() }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    val rotation = remember { Animatable(0f) }
                    LaunchedEffect(syncState) {
                        if (syncState == "Syncing" || syncState == "Saving Attendance..." || syncState == "Processing Payment...") {
                            rotation.animateTo(
                                targetValue = 360f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(1200, easing = LinearEasing),
                                    repeatMode = RepeatMode.Restart
                                )
                            )
                        } else {
                            rotation.snapTo(0f)
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.CloudSync,
                        contentDescription = "Sync Status",
                        tint = if (syncState == "Synced") Color(0xFF4CAF50) else MaterialTheme.colorScheme.secondary,
                        modifier = Modifier
                            .size(16.dp)
                            .rotate(rotation.value)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (syncState == "Synced") "Cloud Match" else syncState,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    if (syncState == "Synced") {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = lastSynced,
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // User Profile Segment with Log Out functionality
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val icon = when (currentRole) {
                        UserRole.ADMIN -> Icons.Default.AdminPanelSettings
                        UserRole.TEACHER -> Icons.Default.CoPresent
                        UserRole.STUDENT -> Icons.Default.LocalLibrary
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = currentRole.name,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = profileName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = when (currentRole) {
                                UserRole.ADMIN -> "Superuser Administration"
                                UserRole.TEACHER -> "Certified Staff Educator"
                                UserRole.STUDENT -> "Academic Family Account"
                            },
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    // Modern Notifications bell with live Badge count
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { onNotificationClick() }
                            .padding(8.dp)
                            .testTag("notification_bell_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (unreadCount > 0) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                            contentDescription = "Open Notifications",
                            tint = if (unreadCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        if (unreadCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .size(14.dp)
                                    .background(Color.Red, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = unreadCount.toString(),
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { viewModel.logoutWithFirebase(context) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp).testTag("logout_button")
                    ) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "logout", modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sign Out", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ================= ADMIN DASHBOARD =================
@Composable
fun AdminDashboard(viewModel: SchoolViewModel) {
    val students by viewModel.students.collectAsStateWithLifecycle()
    val teachers by viewModel.teachers.collectAsStateWithLifecycle()
    val invoices by viewModel.invoices.collectAsStateWithLifecycle()
    val totalRevenue by viewModel.totalRevenueCollected.collectAsStateWithLifecycle()
    val totalPending by viewModel.totalPendingFees.collectAsStateWithLifecycle()
    var activeTab by remember { mutableStateOf(0) } // 0: School Summary, 1: Students, 2: Teachers

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = activeTab) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }) {
                Text("Summary", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }) {
                Text("Students", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Tab(selected = activeTab == 2, onClick = { activeTab = 2 }) {
                Text("Teachers", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeTab) {
                0 -> AdminSummaryView(students.size, teachers.size, totalRevenue, totalPending, viewModel)
                1 -> AdminStudentsView(students, viewModel)
                2 -> AdminTeachersView(teachers, viewModel)
            }
        }
    }
}

@Composable
fun AdminSummaryView(
    studentCount: Int,
    teacherCount: Int,
    revenue: Double,
    pending: Double,
    viewModel: SchoolViewModel
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Splash
        item {
            GlassCard(
                shape = RoundedCornerShape(24.dp), // modern premium 24dp curve
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_erp_banner),
                        contentDescription = "ERP Welcome Illustration",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.7f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxHeight()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "School Admin Hub",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Centralized student directory, batch rosters, and institutional finance reports.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.8f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.width(220.dp)
                        )
                    }
                }
            }
        }

        // Stats Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                GlassCard(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Group, contentDescription = "Students", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Students", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = studentCount.toString(),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text("Active kids enrolled", fontSize = 10.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                    }
                }

                GlassCard(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SupportAgent, contentDescription = "Teachers", tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Faculty", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = teacherCount.toString(),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text("Expert instructors", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f))
                    }
                }
            }
        }

        // Finance Statistics Card
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "School Fee Performance",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Fees Collected", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "$${String.format(Locale.US, "%,.2f", revenue)}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF4CAF50)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Outstanding Balances", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = "$${String.format(Locale.US, "%,.2f", pending)}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Simulated Payment Progress Bar
                    val total = revenue + pending
                    val fraction = if (total > 0) (revenue / total).toFloat() else 0f
                    LinearProgressIndicator(
                        progress = { fraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = Color(0xFF4CAF50),
                        trackColor = MaterialTheme.colorScheme.error.copy(alpha = 0.2f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${(fraction * 100).toInt()}% Payments Cleared",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4CAF50)
                        )
                        Text(
                            text = "${100 - (fraction * 100).toInt()}% Remaining",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Institutional Notice Board
        item {
            GlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Database Sync Status",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "Cloud Active",
                            fontSize = 10.sp,
                            color = Color(0xFF4CAF50),
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Synchronize local school configurations with the secure cloud repository for instant backup and offline access.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.syncCloudData() },
                        modifier = Modifier.fillMaxWidth().testTag("sync_data_btn")
                    ) {
                        Icon(Icons.Default.Sync, contentDescription = "Force Sync")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Force Instant Backup Sync")
                    }
                }
            }
        }

        // School Settings & Sandbox Profile Configuration
        item {
            val context = LocalContext.current
            val schoolNameState by viewModel.schoolNameState.collectAsStateWithLifecycle()
            var editSchoolName by remember { mutableStateOf(false) }
            var tempSchoolName by remember(schoolNameState) { mutableStateOf(schoolNameState) }
            var showClearConfirm by remember { mutableStateOf(false) }
            var showDemoConfirm by remember { mutableStateOf(false) }

            GlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Publishing Settings",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "School Settings & Sandbox Profile",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Customize the school name and database state before publishing to production.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // School Name field
                    if (editSchoolName) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = tempSchoolName,
                                onValueChange = { tempSchoolName = it },
                                label = { Text("School Name", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
                                singleLine = true
                            )
                            IconButton(
                                onClick = {
                                    if (tempSchoolName.isNotBlank()) {
                                        viewModel.updateSchoolName(context, tempSchoolName)
                                        editSchoolName = false
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Save Name", tint = Color(0xFF4CAF50))
                            }
                            IconButton(onClick = { editSchoolName = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Current School Name:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = schoolNameState,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Button(
                                onClick = { editSchoolName = true },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier.testTag("edit_school_name_btn")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Change Name", fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Database Sandbox Control:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Clear Database / Blank Slate
                        Button(
                            onClick = { showClearConfirm = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f).testTag("clear_db_btn")
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Clear Data (Fresh App)", fontSize = 10.sp)
                        }

                        // Load Demo Template Data
                        OutlinedButton(
                            onClick = { showDemoConfirm = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.weight(1f).testTag("load_demo_btn")
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reset to Demo", fontSize = 10.sp)
                        }
                    }
                }
            }

            // Confirm Clean Slate Dialog
            if (showClearConfirm) {
                AlertDialog(
                    onDismissRequest = { showClearConfirm = false },
                    title = { Text("Clear Database to Blank Slate?") },
                    text = { Text("This will delete all current student directories, teachers, assignments, grades, and invoicing data to simulate a completely fresh app launch. Are you sure?") },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                viewModel.clearAllDatabaseRecords()
                                showClearConfirm = false
                            }
                        ) {
                            Text("Yes, Clear All", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showClearConfirm = false }) {
                            Text("Cancel")
                        }
                    }
                )
            }

            // Confirm Restore Demo Dialog
            if (showDemoConfirm) {
                AlertDialog(
                    onDismissRequest = { showDemoConfirm = false },
                    title = { Text("Reload Demo School Template?") },
                    text = { Text("This will overwrite your current storage and pre-populate beautiful, realistic sample data (Aarav, Sneha, math assignments, fee records) for previewing and testing. Proceed?") },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                viewModel.restoreDemoTemplateData()
                                showDemoConfirm = false
                            }
                        ) {
                            Text("Yes, Reload Demo")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDemoConfirm = false }) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }

        // Real-time Bulletin Notice Board
        item {
            InstitutionalNoticeBoard(viewModel = viewModel, canManage = true)
        }
    }
}

@Composable
fun AdminStudentsView(students: List<Student>, viewModel: SchoolViewModel) {
    var showDialog by remember { mutableStateOf(false) }
    val searchQuery by viewModel.studentSearchQuery.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = searchQuery,
                onValueChange = { viewModel.studentSearchQuery.value = it },
                placeholder = { Text("Search Student Name or Roll No") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                modifier = Modifier.weight(1f).testTag("student_search_input"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(10.dp))
            Button(
                onClick = { showDialog = true },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(56.dp).testTag("add_student_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Kid")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (students.isEmpty()) {
            EmptyStatePrompt(
                title = "No Students Found",
                msg = "Press 'Add' to register student records and initialize automated billing cycles."
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(students) { student ->
                    StudentCard(
                        student = student,
                        onDelete = { viewModel.removeStudent(student) },
                        onClick = { viewModel.selectStudent(student.id) }
                    )
                }
            }
        }
    }

    if (showDialog) {
        AddStudentDialog(
            viewModel = viewModel,
            onDismiss = { showDialog = false }
        )
    }
}

@Composable
fun StudentCard(
    student: Student,
    onDelete: () -> Unit,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Profile Initials Circle
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                val initials = if (student.name.isNotBlank()) {
                    val parts = student.name.split(" ")
                    if (parts.size > 1) {
                        "${parts[0].take(1)}${parts[1].take(1)}".uppercase()
                    } else {
                        parts[0].take(2).uppercase()
                    }
                } else "ST"
                Text(
                    text = initials,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = student.name,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    Text(
                        text = "Roll #${student.rollNo}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = student.gradeClass,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Fee Status Light Label
            val feePaidRatio = if (student.totalFees > 0) student.feesPaid / student.totalFees else 1.0
            val badgeColor = when {
                feePaidRatio >= 1.0 -> Color(0xFF4CAF50)
                feePaidRatio > 0.0 -> Color(0xFFFF9800)
                else -> Color(0xFFF44336)
            }
            Box(
                modifier = Modifier
                    .background(badgeColor.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = when {
                        feePaidRatio >= 1.0 -> "Paid"
                        feePaidRatio > 0.0 -> "Partial"
                        else -> "Unpaid"
                    },
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = badgeColor
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Kid", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun AdminTeachersView(teachers: List<Teacher>, viewModel: SchoolViewModel) {
    var showDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Faculty Directory",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Button(onClick = { showDialog = true }, modifier = Modifier.testTag("add_teacher_btn")) {
                Icon(Icons.Default.Add, contentDescription = "Add Faculty")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Register")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (teachers.isEmpty()) {
            EmptyStatePrompt(
                title = "No Teachers Registered",
                msg = "Press 'Register' to create a teacher profile associated with batch rosters."
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(teachers) { teacher ->
                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.SupportAgent, contentDescription = "Instructor", tint = MaterialTheme.colorScheme.secondary)
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = teacher.name,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "Instructor: ${teacher.subject}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Roster Charge: ${teacher.gradeClass}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            IconButton(onClick = { viewModel.removeTeacher(teacher) }) {
                                Icon(Icons.Default.Cancel, contentDescription = "Remove Mentor", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        AddTeacherDialog(
            viewModel = viewModel,
            onDismiss = { showDialog = false }
        )
    }
}

// ================= TEACHER DASHBOARD =================
@Composable
fun TeacherDashboard(viewModel: SchoolViewModel) {
    val students by viewModel.students.collectAsStateWithLifecycle()
    val assignments by viewModel.assignments.collectAsStateWithLifecycle()
    val availableClasses = viewModel.availableClasses

    val selectedClass by viewModel.selectedClassFilter.collectAsStateWithLifecycle()
    val selectedDate by viewModel.attendanceDate.collectAsStateWithLifecycle()
    var activeTab by remember { mutableStateOf(0) } // 0: Attendance register, 1: Assignments, 2: Academic entry

    val classStudents = remember(students, selectedClass) {
        students.filter { it.gradeClass == selectedClass }
    }

    // Local transient states for registers to achieve 60fps scrolling performance
    var attendanceStateMap by remember { mutableStateOf(mapOf<Long, Boolean>()) }
    var previousClassDateKey by remember { mutableStateOf("") }

    val currentKey = "$selectedClass-$selectedDate"
    if (previousClassDateKey != currentKey) {
        previousClassDateKey = currentKey
        // Initialize attendance to all true
        val initialMap = mutableMapOf<Long, Boolean>()
        classStudents.forEach { initialMap[it.id] = true }
        attendanceStateMap = initialMap
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = activeTab) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }) {
                Text("Attendance", modifier = Modifier.padding(11.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }) {
                Text("Homeworks", modifier = Modifier.padding(11.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Tab(selected = activeTab == 2, onClick = { activeTab = 2 }) {
                Text("Grades", modifier = Modifier.padding(11.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Tab(selected = activeTab == 3, onClick = { activeTab = 3 }) {
                Text("Bulletins", modifier = Modifier.padding(11.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        // Selected class dropdown indicator
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Selected Batch Controls", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Roster count: ${classStudents.size}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Class Selector
                    var expanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.weight(1f)) {
                        Button(
                            onClick = { expanded = true },
                            modifier = Modifier.fillMaxWidth().testTag("class_filter_dropdown"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(selectedClass)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "dropdown")
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            availableClasses.forEach { cls ->
                                DropdownMenuItem(
                                    text = { Text(cls) },
                                    onClick = {
                                        viewModel.selectedClassFilter.value = cls
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    // Simulated Date Box (for simplicity, simple textfield)
                    TextField(
                        value = selectedDate,
                        onValueChange = { viewModel.attendanceDate.value = it },
                        modifier = Modifier.weight(1f).testTag("date_input_field"),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                        ),
                        placeholder = { Text("YYYY-MM-DD") }
                    )
                }
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeTab) {
                0 -> TeacherAttendanceRegister(
                    classStudents = classStudents,
                    attendanceState = attendanceStateMap,
                    onToggle = { studentId, present ->
                        val updated = attendanceStateMap.toMutableMap()
                        updated[studentId] = present
                        attendanceStateMap = updated
                    },
                    onSave = {
                        viewModel.saveAttendanceSession(selectedDate, attendanceStateMap)
                    },
                    viewModel = viewModel
                )
                1 -> TeacherAssignmentsView(
                    classAssignments = assignments.filter { it.gradeClass == selectedClass },
                    selectedClass = selectedClass,
                    viewModel = viewModel
                )
                2 -> TeacherGradesEntryView(
                    classStudents = classStudents,
                    viewModel = viewModel
                )
                3 -> Box(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    InstitutionalNoticeBoard(viewModel = viewModel, canManage = true)
                }
            }
        }
    }
}

@Composable
fun TeacherAttendanceRegister(
    classStudents: List<Student>,
    attendanceState: Map<Long, Boolean>,
    onToggle: (Long, Boolean) -> Unit,
    onSave: () -> Unit,
    viewModel: SchoolViewModel
) {
    var viewCumulativeMode by remember { mutableStateOf(false) }
    val allAttendanceRecords by viewModel.allAttendanceRecords.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (viewCumulativeMode) "Cumulative Stats ledger" else "Daily Roll Call Ledger", 
                fontWeight = FontWeight.Bold, 
                style = MaterialTheme.typography.titleMedium
            )
            
            if (!viewCumulativeMode) {
                Button(
                    onClick = onSave,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                    modifier = Modifier.testTag("submit_attendance_btn")
                ) {
                    Icon(Icons.Default.Save, contentDescription = "Save Attendance")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Confirm Roll")
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Mode segmented switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                .padding(4.dp)
        ) {
            listOf("Daily Roll Sheet", "Cumulative Attendance stats").forEachIndexed { index, mode ->
                val active = (index == 0 && !viewCumulativeMode) || (index == 1 && viewCumulativeMode)
                val bg = if (active) MaterialTheme.colorScheme.primary else Color.Transparent
                val tc = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(bg)
                        .clickable { viewCumulativeMode = (index == 1) }
                        .padding(vertical = 8.dp)
                        .testTag("attendance_mode_tab_$index"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(mode, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = tc)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (classStudents.isEmpty()) {
            EmptyStatePrompt(
                title = "No Students",
                msg = "Go to Admin View -> Add Students inside this exact Class Batch."
            )
        } else {
            if (viewCumulativeMode) {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(classStudents) { student ->
                        val studentAttendance = allAttendanceRecords.filter { it.studentId == student.id }
                        val totalDays = studentAttendance.size
                        val presentDays = studentAttendance.count { it.isPresent }
                        val pct = if (totalDays > 0) (presentDays.toDouble() / totalDays) * 100 else 92.0
                        
                        val statusColor = when {
                            pct >= 85 -> Color(0xFF4CAF50)
                            pct >= 75 -> Color(0xFFFF9800)
                            else -> Color(0xFFF44336)
                        }

                        GlassCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(student.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Roll #${student.rollNo} • Total classes tracked: $totalDays", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(top = 4.dp)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = "Present Count", tint = Color(0xFF4CAF50), modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Present: $presentDays", fontSize = 11.sp)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Icon(Icons.Default.Cancel, contentDescription = "Absent Count", tint = Color(0xFFF44336), modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Absent: ${totalDays - presentDays}", fontSize = 11.sp)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = String.format(Locale.US, "%.1f%%", pct),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Black,
                                        color = statusColor
                                    )
                                    Text(
                                        text = if (pct >= 85) "Excellent" else if (pct >= 75) "Low" else "Critical",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = statusColor
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(classStudents) { student ->
                        val isPresent = attendanceState[student.id] ?: true
                        GlassCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(student.name, fontWeight = FontWeight.Bold)
                                    Text("Roll #${student.rollNo}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }

                                // Dynamic Switch Buttons
                                Row {
                                    val presentBg = if (isPresent) Color(0xFF4CAF50) else MaterialTheme.colorScheme.surfaceVariant
                                    val presentTc = if (isPresent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant

                                    val absentBg = if (!isPresent) Color(0xFFF44336) else MaterialTheme.colorScheme.surfaceVariant
                                    val absentTc = if (!isPresent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp))
                                            .background(presentBg)
                                            .clickable { onToggle(student.id, true) }
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                            .testTag("present_btn_${student.id}"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("Present", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = presentTc)
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(topEnd = 12.dp, bottomEnd = 12.dp))
                                            .background(absentBg)
                                            .clickable { onToggle(student.id, false) }
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                            .testTag("absent_btn_${student.id}"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("Absent", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = absentTc)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TeacherAssignmentsView(
    classAssignments: List<Assignment>,
    selectedClass: String,
    viewModel: SchoolViewModel
) {
    var showDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Assigned Research Tasks", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Button(onClick = { showDialog = true }, modifier = Modifier.testTag("add_assignment_btn")) {
                Icon(Icons.Default.Add, contentDescription = "Add Homework")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Post Assignment")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (classAssignments.isEmpty()) {
            EmptyStatePrompt(
                title = "No Homework Posted",
                msg = "Press 'Post Assignment' above to draft task sheets for this batch."
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(classAssignments) { assignment ->
                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(assignment.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Badge(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                                    Text(assignment.subject, color = MaterialTheme.colorScheme.onPrimaryContainer, fontSize = 10.sp, modifier = Modifier.padding(2.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(assignment.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.DateRange, contentDescription = "Due", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Due Date: ${assignment.dueDate}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.secondary)
                                }

                                IconButton(onClick = { viewModel.deleteAssignment(assignment) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "clean", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        PostAssignmentDialog(
            gradeClass = selectedClass,
            viewModel = viewModel,
            onDismiss = { showDialog = false }
        )
    }
}

@Composable
fun TeacherGradesEntryView(
    classStudents: List<Student>,
    viewModel: SchoolViewModel
) {
    var showDialogForStudent by remember { mutableStateOf<Student?>(null) }
    val grades by viewModel.grades.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("Gradebook Records", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Text("Tap on a student profile to record midterm or finals percentages.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Spacer(modifier = Modifier.height(12.dp))

        if (classStudents.isEmpty()) {
            EmptyStatePrompt(
                title = "No Class Studs",
                msg = "No student accounts present to compile academic reports."
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(classStudents) { student ->
                    val studentGrades = grades.filter { it.studentId == student.id }
                    val gpa = if (studentGrades.isNotEmpty()) {
                        studentGrades.sumOf { it.marksObtained } / studentGrades.sumOf { it.maxMarks } * 100
                    } else null

                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showDialogForStudent = student }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(student.name, fontWeight = FontWeight.Bold)
                                Text("Registered entries: ${studentGrades.size} exams", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            if (gpa != null) {
                                Box(
                                    modifier = Modifier
                                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "${String.format(Locale.US, "%.1f", gpa)}%",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            } else {
                                Text(
                                    text = "No Marks",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialogForStudent != null) {
        RecordGradeDialog(
            student = showDialogForStudent!!,
            viewModel = viewModel,
            onDismiss = { showDialogForStudent = null }
        )
    }
}


// ================= STUDENT / PARENT PORTAL =================
@Composable
fun StudentPortal(viewModel: SchoolViewModel) {
    val students by viewModel.students.collectAsStateWithLifecycle()
    val invoices by viewModel.invoices.collectAsStateWithLifecycle()
    val assignments by viewModel.assignments.collectAsStateWithLifecycle()
    val grades by viewModel.grades.collectAsStateWithLifecycle()
    val allAttendanceRecords by viewModel.allAttendanceRecords.collectAsStateWithLifecycle()

    val activeStudentId by viewModel.selectedStudentId.collectAsStateWithLifecycle()

    LaunchedEffect(activeStudentId, students) {
        if (activeStudentId == null && students.isNotEmpty()) {
            viewModel.selectStudent(students[0].id)
        }
    }

    val activeStudent = students.find { it.id == activeStudentId }

    if (students.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            EmptyStatePrompt(
                title = "No Academic Profiles Found",
                msg = "Go to Admin View or Teachers segment first to seed student batches."
            )
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Simple horizontal scroll to switch active student (for parents managing multiple children)
        Text("Selected Student Account", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            students.take(4).forEach { child ->
                val isActive = child.id == activeStudentId
                val cardColor = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                val textCol = if (isActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(cardColor)
                        .clickable { viewModel.selectStudent(child.id) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("child_pill_${child.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(child.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textCol)
                }
            }
        }

        if (activeStudent != null) {
            val studentInvoices = invoices.filter { it.studentId == activeStudent.id }
            val studentGrades = grades.filter { it.studentId == activeStudent.id }
            val studentAssignments = assignments.filter { it.gradeClass == activeStudent.gradeClass }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Kid profile info
                item {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .background(Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = "Student Avatar", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(activeStudent.name, fontWeight = FontWeight.Bold, fontSize = 21.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                Text("Class: ${activeStudent.gradeClass}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                                Text("Roll Number: ${activeStudent.rollNo}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Phone, contentDescription = "call", modifier = Modifier.size(10.dp), tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(activeStudent.contactNo, fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                }
                            }
                        }
                    }
                }

                // Merit & Achievement Badges Section
                item {
                    val studentAttendance = allAttendanceRecords.filter { it.studentId == activeStudent.id }
                    val totalDays = studentAttendance.size
                    val presentDays = studentAttendance.count { it.isPresent }
                    val attendancePct = if (totalDays > 0) (presentDays.toDouble() / totalDays) * 100 else 92.0
                    val isPendingFees = studentInvoices.any { it.status != "Paid" }

                    Column {
                        Text("Merit & Achievement Badges", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        androidx.compose.foundation.lazy.LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Badge 1: Attendance Star
                            if (attendancePct >= 90.0) {
                                item {
                                    BadgeItem(icon = Icons.Default.Verified, title = "Attendance Star", desc = "Over 90% Presence", color = Color(0xFF4CAF50))
                                }
                            }
                            // Badge 2: Discipline Hero
                            item {
                                BadgeItem(icon = Icons.Default.Star, title = "Discipline Hero", desc = "Excellent Behavior", color = Color(0xFFE91E63))
                            }
                            // Badge 3: Active Scholar
                            if (studentAssignments.isNotEmpty()) {
                                item {
                                    BadgeItem(icon = Icons.Default.MenuBook, title = "Academics Active", desc = "Homework Sync", color = Color(0xFF2196F3))
                                }
                            }
                            // Badge 4: All Fees Settled
                            if (!isPendingFees) {
                                item {
                                    BadgeItem(icon = Icons.Default.CheckCircle, title = "Super Compliant", desc = "All Fees Settled", color = Color(0xFFFF9800))
                                }
                            }
                        }
                    }
                }

                // Dynamic Weekly Timetable
                item {
                    var showTimetable by remember { mutableStateOf(false) }
                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().clickable { showTimetable = !showTimetable },
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AccessTime,
                                        contentDescription = "Timetable Icon",
                                        tint = Color(0xFF9C27B0), // Purple color icon
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "Today's Class Timetable",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Text(
                                            text = if (showTimetable) "Tap to collapse timetable" else "Tap to view subject periods",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = if (showTimetable) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (showTimetable) {
                                Spacer(modifier = Modifier.height(14.dp))
                                val schedule = listOf(
                                    "08:30 AM - 09:15 AM" to "Mathematics (Period 1)",
                                    "09:15 AM - 10:00 AM" to "General Science (Period 2)",
                                    "10:00 AM - 10:15 AM" to "Short Break / Recess 🍎",
                                    "10:15 AM - 11:00 AM" to "English Literature (Period 3)",
                                    "11:00 AM - 11:45 AM" to "Social Studies (Period 4)",
                                    "11:45 AM - 12:30 PM" to "Computer Science / Lab (Period 5)"
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    schedule.forEach { (time, subject) ->
                                        val isBreak = subject.contains("Break")
                                        val rowBg = if (isBreak) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                        val borderCol = if (isBreak) Color(0xFF4CAF50).copy(alpha = 0.5f) else Color.Transparent

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(rowBg, RoundedCornerShape(8.dp))
                                                .border(1.dp, borderCol, RoundedCornerShape(8.dp))
                                                .padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = subject,
                                                fontWeight = if (isBreak) FontWeight.Bold else FontWeight.SemiBold,
                                                fontSize = 12.sp,
                                                color = if (isBreak) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = time,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = if (isBreak) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Direct Principal / Help Desk Quick Query Contact
                item {
                    var showForm by remember { mutableStateOf(false) }
                    var messageText by remember { mutableStateOf("") }
                    val context = LocalContext.current

                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().clickable { showForm = !showForm },
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Email,
                                        contentDescription = "Help Icon",
                                        tint = Color(0xFFFF5722), // High priority Coral red/orange color
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "Instant Help & Query Desk",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Text(
                                            text = "Need help? Send a secure message directly to Admin",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = if (showForm) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (showForm) {
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = messageText,
                                    onValueChange = { messageText = it },
                                    label = { Text("How can we help your child today?", fontSize = 12.sp) },
                                    placeholder = { Text("Write your request, transport queries or administrative questions here...", fontSize = 11.sp) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp),
                                    maxLines = 3
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        if (messageText.isNotBlank()) {
                                            android.widget.Toast.makeText(context, "Query submitted securely to Administrative Desk!", android.widget.Toast.LENGTH_SHORT).show()
                                            messageText = ""
                                            showForm = false
                                        } else {
                                            android.widget.Toast.makeText(context, "Please enter some text.", android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5722)),
                                    enabled = messageText.isNotBlank(),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.align(Alignment.End).testTag("send_support_query_btn")
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Submit Request", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // Student Invoices / Fees with simulated checkout
                item {
                    Text("My School Fees / Invoices", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    if (studentInvoices.isEmpty()) {
                        Text("All fees paid! No pending invoices.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        studentInvoices.forEach { invoice ->
                            val statusColor = if (invoice.status == "Paid") Color(0xFF4CAF50) else Color(0xFFF44336)
                            GlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(invoice.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("Due Date: ${invoice.dueDate}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                                            Box(modifier = Modifier.size(6.dp).background(statusColor, CircleShape))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(invoice.status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = statusColor)
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("$${invoice.amount}", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                                        if (invoice.status != "Paid") {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Button(
                                                onClick = { viewModel.processPaymentForInvoice(invoice) },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.height(28.dp).testTag("pay_invoice_btn_${invoice.id}"),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                                            ) {
                                                Text("Pay Now", fontSize = 10.sp, color = Color.White)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. Attendance (On top of Notice)
                item {
                    val studentAttendance = allAttendanceRecords.filter { it.studentId == activeStudent.id }
                    val totalDays = studentAttendance.size
                    val presentDays = studentAttendance.count { it.isPresent }
                    val attendancePct = if (totalDays > 0) {
                        (presentDays.toDouble() / totalDays) * 100
                    } else {
                        92.0
                    }

                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = "Attendance Calendar Icon",
                                tint = Color(0xFF4CAF50), // Color thoda friendly and specific
                                modifier = Modifier.size(36.dp) // Icon thoda bada
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = "School Attendance",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = String.format(Locale.US, "%.1f%% Presence (%d/%d Days)", attendancePct, presentDays, if (totalDays > 0) totalDays else 5),
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // 3. Notices (Below Attendance)
                item {
                    InstitutionalNoticeBoard(viewModel = viewModel, canManage = false)
                }

                // 4. Homework & Assignments (Below Notice, and inside it everything)
                item {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = "Homework Icon",
                                    tint = Color(0xFF2196F3), // Color thoda bright sky blue
                                    modifier = Modifier.size(36.dp) // Icon thoda bada
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Homework & Assignments",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            if (studentAssignments.isEmpty()) {
                                Text("No homework pending! Clean slate.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                studentAssignments.forEach { assignment ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(assignment.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text(assignment.subject, fontSize = 11.sp, color = Color(0xFF2196F3), fontWeight = FontWeight.Bold)
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(assignment.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text("Due Date: ${assignment.dueDate}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 5. Report Cards (Below Homework, with specified pink/gold report card icon)
                item {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Assessment,
                                    contentDescription = "Report Card Icon",
                                    tint = Color(0xFFE91E63), // Color of report card is Pink
                                    modifier = Modifier.size(36.dp) // Icon thoda bada
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Progress Report Cards",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))

                            val studentAttendance = allAttendanceRecords.filter { it.studentId == activeStudent.id }
                            AutomaticReportCardCard(
                                student = activeStudent,
                                grades = studentGrades,
                                attendance = studentAttendance
                            )

                            Spacer(modifier = Modifier.height(14.dp))
                            Text("Exam Marks Breakdown:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(6.dp))

                            if (studentGrades.isEmpty()) {
                                Text("No exam scores uploaded yet.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            } else {
                                studentGrades.forEach { grade ->
                                    val scorePercentage = (grade.marksObtained / grade.maxMarks) * 100
                                    val letterGrade = when {
                                        scorePercentage >= 90 -> "A+"
                                        scorePercentage >= 80 -> "A"
                                        scorePercentage >= 70 -> "B"
                                        scorePercentage >= 60 -> "C"
                                        else -> "F"
                                    }
                                    val cardBg = if (letterGrade == "F") Color(0xFFFFEBEE) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)

                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        colors = CardDefaults.cardColors(containerColor = cardBg)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text(grade.subject, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text(grade.examName, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text("Score: ${grade.marksObtained}/${grade.maxMarks}", fontSize = 11.sp)
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .background(Color(0xFFE91E63), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = letterGrade,
                                                    fontWeight = FontWeight.Black,
                                                    fontSize = 12.sp,
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BadgeItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, desc: String, color: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.08f)),
        border = BorderStroke(1.2.dp, color.copy(alpha = 0.35f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.width(135.dp).padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = desc,
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}


// ================= HELPER ELEMENTS =================
@Composable
fun EmptyStatePrompt(title: String, msg: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Inbox,
            contentDescription = "empty",
            tint = MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f),
            modifier = Modifier.size(54.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = msg,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
        )
    }
}

// Dialog overlays for administrative functions
@Composable
fun AddStudentDialog(
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var rollNo by remember { mutableStateOf("") }
    var cls by remember { mutableStateOf("Class 10-A") }
    var contact by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var tuitionFee by remember { mutableStateOf("1500") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Register Student", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Student Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_student_name")
                )
                OutlinedTextField(
                    value = rollNo,
                    onValueChange = { rollNo = it },
                    label = { Text("Roll Number") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_student_roll")
                )
                
                // Simple dropdown
                var expanded by remember { mutableStateOf(false) }
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { expanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Assigned Class: $cls")
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        viewModel.availableClasses.forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = {
                                cls = item
                                expanded = false
                            })
                        }
                    }
                }

                OutlinedTextField(
                    value = contact,
                    onValueChange = { contact = it },
                    label = { Text("Parent Contact Phone") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = tuitionFee,
                    onValueChange = { tuitionFee = it },
                    label = { Text("Term Dues / Fees ($)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && rollNo.isNotBlank()) {
                        viewModel.addNewStudent(
                            name = name,
                            rollNo = rollNo,
                            gradeClass = cls,
                            contactNo = contact,
                            email = email,
                            termFees = tuitionFee.toDoubleOrNull() ?: 1500.0
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("submit_student_btn")
            ) {
                Text("Confirm Enrollment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddTeacherDialog(
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var cls by remember { mutableStateOf("Class 10-A") }
    var contact by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Faculty Registration", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Instructor Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("teacher_name_input")
                )
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Primary Subject specialization") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                var expanded by remember { mutableStateOf(false) }
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { expanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Roster Control: $cls")
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        viewModel.availableClasses.forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = {
                                cls = item
                                expanded = false
                            })
                        }
                    }
                }

                OutlinedTextField(
                    value = contact,
                    onValueChange = { contact = it },
                    label = { Text("Contact Phone") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Institutional Email") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        viewModel.addNewTeacher(
                            name = name,
                            subject = subject,
                            contactNo = contact,
                            email = email,
                            gradeClass = cls
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("submit_teacher_btn")
            ) {
                Text("Confirm Register")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun PostAssignmentDialog(
    gradeClass: String,
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf("2026-06-30") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Draft New Roster Task", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Assignment Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("assignment_title_input")
                )
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject Area") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Task Description / Instructions") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dueDate,
                    onValueChange = { dueDate = it },
                    label = { Text("Submission Due Date") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        viewModel.postAssignment(
                            title = title,
                            description = desc,
                            subject = subject,
                            dueDate = dueDate,
                            gradeClass = gradeClass
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("submit_assignment_btn")
            ) {
                Text("Post Assignment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun RecordGradeDialog(
    student: Student,
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit
) {
    var examName by remember { mutableStateOf("Term 1 Examination") }
    var subject by remember { mutableStateOf("Mathematics") }
    var marksReceived by remember { mutableStateOf("") }
    var maxMarks by remember { mutableStateOf("100") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Grades: ${student.name}", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = examName,
                    onValueChange = { examName = it },
                    label = { Text("Examination Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                
                // Fast Subject Selector Outlined
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject Area") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = marksReceived,
                    onValueChange = { marksReceived = it },
                    label = { Text("Marks Obtained") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("marks_obtained_input")
                )
                OutlinedTextField(
                    value = maxMarks,
                    onValueChange = { maxMarks = it },
                    label = { Text("Maximum Marks") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val marks = marksReceived.toDoubleOrNull()
                    val total = maxMarks.toDoubleOrNull()
                    if (marks != null && total != null) {
                        viewModel.addStudentGrade(
                            studentId = student.id,
                            subject = subject,
                            examName = examName,
                            marksObtained = marks,
                            maxMarks = total
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.testTag("submit_grade_btn")
            ) {
                Text("Post Grade Card")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun NotificationsDialog(viewModel: SchoolViewModel, onDismiss: () -> Unit) {
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val loggedInStudentId by viewModel.loggedInStudentId.collectAsStateWithLifecycle()

    val filteredNotifications = notifications.filter {
        when (currentRole) {
            UserRole.ADMIN -> it.targetRole == UserRole.ADMIN
            UserRole.TEACHER -> it.targetRole == UserRole.TEACHER
            UserRole.STUDENT -> it.targetRole == UserRole.STUDENT && (it.targetUserId == null || it.targetUserId == loggedInStudentId)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Alerts & Directives",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                if (filteredNotifications.isNotEmpty()) {
                    TextButton(onClick = { viewModel.clearAllNotifications() }) {
                        Text("Clear All", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 400.dp)
            ) {
                if (filteredNotifications.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.MarkChatRead,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Zero Unresolved Alerts",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Your academic feed is completely synchronized and up-to-date.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(filteredNotifications) { item ->
                            val cardColor = if (item.isRead) {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            } else {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                            }
                            val borderStroke = if (item.isRead) {
                                BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            } else {
                                BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                            }

                            val typeIcon = when (item.type) {
                                "Grade" -> Icons.Default.Grade
                                "Assignment" -> Icons.Default.Assignment
                                "Fee Due" -> Icons.Default.MonetizationOn
                                "Receipt" -> Icons.Default.ReceiptLong
                                "System" -> Icons.Default.Computer
                                else -> Icons.Default.Info
                            }

                            val iconColor = when (item.type) {
                                "Grade" -> Color(0xFFE91E63)
                                "Assignment" -> Color(0xFF2196F3)
                                "Fee Due" -> Color(0xFFFF9800)
                                "Receipt" -> Color(0xFF4CAF50)
                                "System" -> Color(0xFF9C27B0)
                                else -> MaterialTheme.colorScheme.primary
                            }

                            Card(
                                onClick = { viewModel.markNotificationAsRead(item.id) },
                                colors = CardDefaults.cardColors(containerColor = cardColor),
                                border = borderStroke,
                                modifier = Modifier.fillMaxWidth().testTag("notification_item_${item.id}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(
                                        imageVector = typeIcon,
                                        contentDescription = item.type,
                                        tint = iconColor,
                                        modifier = Modifier
                                            .size(24.dp)
                                            .background(iconColor.copy(alpha = 0.12f), CircleShape)
                                            .padding(4.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = item.title,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            if (!item.isRead) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = item.message,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = item.timestamp,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier.testTag("dismiss_notifications_btn")
            ) {
                Text("Dismiss")
            }
        }
    )
}

@Composable
fun FeeReceiptDialog(receipt: FeeReceipt, onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(12.dp))
                    .padding(2.dp)
                    .clipToBounds()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF0F2027), Color(0xFF203A43))
                            )
                        )
                        .padding(vertical = 16.dp, horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = Color(0xFF4CAF50),
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = receipt.schoolName.uppercase(),
                            color = Color.White,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp
                            ),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "OFFICIAL TRANSACTION RECEIPT",
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 9.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                ) {
                    val segments = size.width / 16.dp.toPx()
                    for (i in 0 until segments.toInt()) {
                        drawCircle(
                            color = Color(0xFFE0E0E0),
                            radius = 3.dp.toPx(),
                            center = androidx.compose.ui.geometry.Offset(
                                x = i * 16.dp.toPx() + 8.dp.toPx(),
                                y = 4.dp.toPx()
                            )
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFFCFCFC))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("RECEIPT NO.", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 9.sp)
                            Text(receipt.receiptNo, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = Color.Black)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("DATE & TIME", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 9.sp)
                            Text(receipt.paymentDate, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = Color.Black)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = Color(0xFFF1F1F1), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("STUDENT CREDENTIALS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color(0xFF203A43), fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Name:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                        Text(receipt.studentName, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = Color.Black)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Student ID:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                        Text("#${receipt.studentId}", style = MaterialTheme.typography.bodySmall, color = Color.Black)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Class / Division:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                        Text(receipt.studentClass, style = MaterialTheme.typography.bodySmall, color = Color.Black)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Roll Number:", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                        Text(receipt.studentRoll, style = MaterialTheme.typography.bodySmall, color = Color.Black)
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = Color(0xFFF1F1F1), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("BILLING DESCRIPTION", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color(0xFF203A43), fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF5F5F5), RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(receipt.invoiceTitle, style = MaterialTheme.typography.bodySmall, color = Color.Black, modifier = Modifier.weight(1f))
                        Text(
                            text = "USD ${receipt.amountPaid}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.Black
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AMOUNT RECEIVED",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = Color(0xFF203A43)
                        )
                        Text(
                            text = "USD ${receipt.amountPaid}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black),
                            color = Color(0xFF4CAF50),
                            fontSize = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            modifier = Modifier
                                .border(BorderStroke(2.dp, Color(0xFF4CAF50)), RoundedCornerShape(4.dp))
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                                .rotate(-4f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "PAID - SYNCED",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                ),
                                color = Color(0xFF4CAF50),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                OutlinedButton(
                    onClick = {
                        android.widget.Toast.makeText(context, "Receipt PDF downloaded to Local Storage!", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("download_receipt_pdf")
                ) {
                    Icon(Icons.Default.Download, contentDescription = "Download PDF", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Download PDF", fontSize = 12.sp)
                }
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dismiss_receipt_btn")
                ) {
                    Text("Done")
                }
            }
        }
    )
}
