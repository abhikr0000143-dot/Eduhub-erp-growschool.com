package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SchoolNotice(
    val id: Long,
    val title: String,
    val content: String,
    val dateStr: String,
    val category: String, // "Academic", "Urgent", "Holiday", "Events"
    val author: String
)

data class AppNotification(
    val id: Long,
    val title: String,
    val message: String,
    val timestamp: String,
    val type: String, // "Grade", "Assignment", "Fee Due", "Notice", "Receipt", "System"
    val targetRole: UserRole,
    val targetUserId: Long? = null, // null means all of that role
    val isRead: Boolean = false
)

data class FeeReceipt(
    val receiptNo: String,
    val schoolName: String,
    val studentName: String,
    val studentId: Long,
    val studentClass: String,
    val studentRoll: String,
    val invoiceTitle: String,
    val amountPaid: Double,
    val paymentDate: String,
    val paymentStatus: String,
    val isDownloaded: Boolean = false
)

enum class UserRole {
    ADMIN, TEACHER, STUDENT
}

class SchoolViewModel(private val repository: SchoolRepository) : ViewModel() {

    // Roles and navigation status
    private val _currentRole = MutableStateFlow(UserRole.ADMIN)
    val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

    private val _selectedStudentId = MutableStateFlow<Long?>(null)
    val selectedStudentId: StateFlow<Long?> = _selectedStudentId.asStateFlow()

    // Notifications and Receipts State
    private val _notifications = MutableStateFlow<List<AppNotification>>(
        listOf(
            AppNotification(
                id = 1L,
                title = "Welcome to EduHub Portal",
                message = "Secure SaaS cloud connectivity initialized successfully. All roles are fully mapped.",
                timestamp = "2026-06-22 09:00",
                type = "System",
                targetRole = UserRole.STUDENT
            )
        )
    )
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _lastGeneratedReceipt = MutableStateFlow<FeeReceipt?>(null)
    val lastGeneratedReceipt: StateFlow<FeeReceipt?> = _lastGeneratedReceipt.asStateFlow()

    fun addNotification(title: String, message: String, type: String, targetRole: UserRole, targetUserId: Long? = null) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val timestamp = sdf.format(Date())
        val newNotification = AppNotification(
            id = System.currentTimeMillis(),
            title = title,
            message = message,
            timestamp = timestamp,
            type = type,
            targetRole = targetRole,
            targetUserId = targetUserId,
            isRead = false
        )
        _notifications.value = listOf(newNotification) + _notifications.value
        Log.d("SchoolViewModel", "Notification raised: $title - $message")
    }

    fun markNotificationAsRead(id: Long) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    fun clearAllNotifications() {
        _notifications.value = emptyList()
    }

    fun dismissReceipt() {
        _lastGeneratedReceipt.value = null
    }

    fun generateFeeNotificationsForStudent(studentId: Long) {
        viewModelScope.launch {
            val student = repository.getStudentById(studentId)
            if (student != null) {
                val outstanding = student.totalFees - student.feesPaid
                if (outstanding > 0) {
                    addNotification(
                        title = "Pending Tuition Fees Alert",
                        message = "Your accounts summary shows outstanding balance of USD $outstanding in academic tuition fees. Please complete payment.",
                        type = "Fee Due",
                        targetRole = UserRole.STUDENT,
                        targetUserId = studentId
                    )
                }

                // Simulate "1 month elapsed / fee cycle time" warning
                addNotification(
                    title = "Monthly Fee Payment Cycle Active",
                    message = "Academic Fee Reminder: 1 month has elapsed since your enrollment cycle. Please review fee invoice items.",
                    type = "Fee Due",
                    targetRole = UserRole.STUDENT,
                    targetUserId = studentId
                )
            }
        }
    }

    // Login States
    private val _isUserLoggedIn = MutableStateFlow(false)
    val isUserLoggedIn: StateFlow<Boolean> = _isUserLoggedIn.asStateFlow()

    private val _loggedInTeacherId = MutableStateFlow<Long?>(null)
    val loggedInTeacherId: StateFlow<Long?> = _loggedInTeacherId.asStateFlow()

    private val _loggedInStudentId = MutableStateFlow<Long?>(null)
    val loggedInStudentId: StateFlow<Long?> = _loggedInStudentId.asStateFlow()

    fun loginAsAdmin() {
        _currentRole.value = UserRole.ADMIN
        _isUserLoggedIn.value = true
        syncCloudData()
    }

    fun loginAsTeacher(teacherId: Long) {
        _currentRole.value = UserRole.TEACHER
        _loggedInTeacherId.value = teacherId
        _isUserLoggedIn.value = true
        viewModelScope.launch {
            val teach = teachers.value.find { it.id == teacherId }
            if (teach != null) {
                selectedClassFilter.value = teach.gradeClass
            }
        }
        syncCloudData()
    }

    fun loginAsStudent(studentId: Long) {
        _currentRole.value = UserRole.STUDENT
        _loggedInStudentId.value = studentId
        _selectedStudentId.value = studentId
        _isUserLoggedIn.value = true
        viewModelScope.launch {
            val stud = students.value.find { it.id == studentId }
            if (stud != null) {
                selectedClassFilter.value = stud.gradeClass
            }
        }
        generateFeeNotificationsForStudent(studentId)
        syncCloudData()
    }

    fun loginWithFirebase(context: android.content.Context, email: String, pass: String, onComplete: (String?) -> Unit) {
        FirebaseAuthService.performSignIn(context, email, pass) { result ->
            when (result) {
                is AuthResult.Success -> {
                    FirebaseAuthService.storeActiveSession(context, result.email)
                    viewModelScope.launch {
                        val matchedStudent = students.value.find { it.email.lowercase().trim() == result.email.lowercase().trim() }
                        val matchedTeacher = teachers.value.find { it.email.lowercase().trim() == result.email.lowercase().trim() }

                        when {
                            result.role == "ADMIN" || result.email.lowercase().startsWith("admin") -> {
                                loginAsAdmin()
                                onComplete(null)
                            }
                            matchedTeacher != null -> {
                                loginAsTeacher(matchedTeacher.id)
                                onComplete(null)
                            }
                            matchedStudent != null -> {
                                loginAsStudent(matchedStudent.id)
                                onComplete(null)
                            }
                            result.role == "TEACHER" -> {
                                val newId = repository.insertTeacher(Teacher(
                                    name = result.email.substringBefore("@").replaceFirstChar { it.uppercase() },
                                    subject = "General Sciences",
                                    contactNo = "+1 (555) 019-2831",
                                    email = result.email,
                                    gradeClass = "Class A"
                                ))
                                loginAsTeacher(newId)
                                onComplete(null)
                            }
                            else -> {
                                val newId = repository.insertStudent(Student(
                                    name = result.email.substringBefore("@").replaceFirstChar { it.uppercase() },
                                    rollNo = "R-${(101..999).random()}",
                                    gradeClass = "Class A",
                                    contactNo = "+1 (555) 014-9821",
                                    email = result.email,
                                    totalFees = 1500.0,
                                    feesPaid = 0.0
                                ))
                                loginAsStudent(newId)
                                onComplete(null)
                            }
                        }
                    }
                }
                is AuthResult.Error -> {
                    onComplete(result.message)
                }
            }
        }
    }

    fun signUpWithFirebase(
        context: android.content.Context,
        email: String,
        pass: String,
        role: String,
        name: String,
        extraValue: String,
        onComplete: (String?) -> Unit
    ) {
        FirebaseAuthService.performSignUp(context, email, pass, role, name) { result ->
            when (result) {
                is AuthResult.Success -> {
                    FirebaseAuthService.storeActiveSession(context, result.email)
                    viewModelScope.launch {
                        when (role) {
                            "ADMIN" -> {
                                loginAsAdmin()
                                onComplete(null)
                            }
                            "TEACHER" -> {
                                val newId = repository.insertTeacher(Teacher(
                                    name = name,
                                    subject = extraValue.ifEmpty { "General Sciences" },
                                    contactNo = "+1 (555) 019-2831",
                                    email = email,
                                    gradeClass = "Class A"
                                ))
                                loginAsTeacher(newId)
                                onComplete(null)
                            }
                            else -> {
                                val newId = repository.insertStudent(Student(
                                    name = name,
                                    rollNo = extraValue.ifEmpty { "R-${(101..199).random()}" },
                                    gradeClass = "Class A",
                                    contactNo = "+1 (555) 014-9821",
                                    email = email,
                                    totalFees = 2000.0,
                                    feesPaid = 1500.0
                                ))
                                loginAsStudent(newId)
                                onComplete(null)
                            }
                        }
                    }
                }
                is AuthResult.Error -> {
                    onComplete(result.message)
                }
            }
        }
    }

    fun logout() {
        _isUserLoggedIn.value = false
        _loggedInTeacherId.value = null
        _loggedInStudentId.value = null
        syncCloudData()
    }

    fun logoutWithFirebase(context: android.content.Context) {
        FirebaseAuthService.performSignOut(context)
        logout()
    }

    fun checkPersistedSession(context: android.content.Context) {
        val savedEmail = FirebaseAuthService.getActiveSessionUser(context)
        if (!savedEmail.isNullOrEmpty()) {
            viewModelScope.launch {
                try {
                    // Wait for students or teachers flows to populate or time out
                    combine(students, teachers) { s, t -> s.isNotEmpty() || t.isNotEmpty() }
                        .filter { it }
                        .first()
                } catch (e: Exception) {
                    // Fallthrough if any error
                }

                val matchedStudent = students.value.find { it.email.lowercase().trim() == savedEmail.lowercase().trim() }
                val matchedTeacher = teachers.value.find { it.email.lowercase().trim() == savedEmail.lowercase().trim() }

                when {
                    savedEmail.lowercase().startsWith("admin") || savedEmail.lowercase().contains("admin") -> {
                        loginAsAdmin()
                    }
                    matchedTeacher != null -> {
                        loginAsTeacher(matchedTeacher.id)
                    }
                    matchedStudent != null -> {
                        loginAsStudent(matchedStudent.id)
                    }
                    else -> {
                        // Safe default fallback
                        loginAsAdmin()
                    }
                }
            }
        }
    }

    // Dynamic Notices State
    private val _notices = MutableStateFlow<List<SchoolNotice>>(
        listOf(
            SchoolNotice(
                id = 1,
                title = "📣 Mid-Term Results & Report Cards Active",
                content = "Subject teachers have compiled the overall term grade percentages. Students can now check their dynamic GPA report cards instantly from their portals.",
                dateStr = "2026-06-22",
                category = "Academic",
                author = "Academic Dean"
            ),
            SchoolNotice(
                id = 2,
                title = "🚌 Monsoon Bus Route Timings Rescheduled",
                content = "Morning pick-up slots will start 15 minutes earlier starting next Monday to avoid transit rain delays. View individual routes on transport pane.",
                dateStr = "2026-06-20",
                category = "Urgent",
                author = "Transport Admin"
            ),
            SchoolNotice(
                id = 3,
                title = "🏆 Science & Tech Fair Registration Open",
                content = "Theme: Sustainable Ecosystem Science. Submit brief abstract ideas to Dr. Evelyn Foster by June 30th to qualify for the regional science expo.",
                dateStr = "2026-06-18",
                category = "Events",
                author = "Dr. Evelyn"
            ),
            SchoolNotice(
                id = 4,
                title = "🏖️ Summer Term Conclave Holiday Notification",
                content = "School academic classes will remain suspended on July 1st in celebration of the regional sports awards conclave. Have a safe weekend, guys!",
                dateStr = "2026-06-15",
                category = "Holiday",
                author = "Principal Office"
            )
        )
    )
    val notices: StateFlow<List<SchoolNotice>> = _notices.asStateFlow()

    fun addNotice(title: String, content: String, category: String, author: String) {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dateStr = sdf.format(Date())
        val newNotice = SchoolNotice(
            id = System.currentTimeMillis(),
            title = title,
            content = content,
            dateStr = dateStr,
            category = category,
            author = author
        )
        _notices.value = listOf(newNotice) + _notices.value
        
        // Raise system-triggered alerts for user roles
        addNotification(
            title = "Notice: $title",
            message = "$content (Category: $category)",
            type = "Notice",
            targetRole = UserRole.STUDENT
        )
        addNotification(
            title = "New System Announcement",
            message = "\"$title\" released by $author.",
            type = "Notice",
            targetRole = UserRole.TEACHER
        )

        syncCloudData()
    }

    fun deleteNotice(noticeId: Long) {
        _notices.value = _notices.value.filter { it.id != noticeId }
        syncCloudData()
    }

    // Filter properties
    val selectedClassFilter = MutableStateFlow("Class 10-A")
    val studentSearchQuery = MutableStateFlow("")
    val attendanceDate = MutableStateFlow("2026-06-22")

    // Syncing state
    private val _syncState = MutableStateFlow("Synced") // "Synced", "Syncing", "Offline"
    val syncState: StateFlow<String> = _syncState.asStateFlow()

    private val _lastSyncedTime = MutableStateFlow("Just now")
    val lastSyncedTime: StateFlow<String> = _lastSyncedTime.asStateFlow()

    // Available Classes/Grades
    val availableClasses = listOf("Class 10-A", "Class 10-B", "Class 11-A", "Class 11-B", "Class 12-A")

    init {
        viewModelScope.launch {
            repository.seedMockDataIfEmpty()
        }
    }

    // Observed collections from Room Database
    val students: StateFlow<List<Student>> = combine(
        repository.allStudents,
        studentSearchQuery
    ) { studentList, query ->
        if (query.isBlank()) {
            studentList
        } else {
            studentList.filter {
                it.name.contains(query, ignoreCase = true) ||
                        it.rollNo.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val teachers: StateFlow<List<Teacher>> = repository.allTeachers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val assignments : StateFlow<List<Assignment>> = repository.allAssignments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val invoices : StateFlow<List<Invoice>> = repository.allInvoices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val grades: StateFlow<List<GradeRecord>> = repository.allGrades
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAttendanceRecords: StateFlow<List<AttendanceRecord>> = repository.allAttendanceRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Financial calculations
    val totalRevenueCollected: StateFlow<Double> = invoices.map { invoiceList ->
        invoiceList.filter { it.status == "Paid" }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalPendingFees: StateFlow<Double> = invoices.map { invoiceList ->
        invoiceList.filter { it.status == "Pending" || it.status == "Overdue" }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Set Role
    fun setRole(role: UserRole) {
        _currentRole.value = role
    }

    // Set Selected Student
    fun selectStudent(id: Long?) {
        _selectedStudentId.value = id
    }

    // Robust real-time cloud sync with bi-directional Room <-> Firebase Firestore matching
    fun syncCloudData() {
        viewModelScope.launch {
            _syncState.value = "Syncing"
            try {
                if (FirestoreService.isFirestoreAvailable) {
                    // Push local Student updates to Firestore
                    val localStudents = repository.allStudents.first()
                    localStudents.forEach { FirestoreService.saveStudent(it) }

                    // Push local Teacher updates to Firestore
                    val localTeachers = repository.allTeachers.first()
                    localTeachers.forEach { FirestoreService.saveTeacher(it) }

                    // Push local GradeRecord updates to Firestore
                    val localGrades = repository.allGrades.first()
                    localGrades.forEach { FirestoreService.saveGradeRecord(it) }

                    // Push local AttendanceRecord updates to Firestore
                    val localAttendance = repository.allAttendanceRecords.first()
                    localAttendance.forEach { FirestoreService.saveAttendanceRecord(it) }

                    // Pull Firestore changes & merge back to local database
                    FirestoreService.fetchStudents { cloudStudents ->
                        viewModelScope.launch {
                            cloudStudents.forEach { stud ->
                                repository.insertStudent(stud)
                            }
                        }
                    }

                    FirestoreService.fetchTeachers { cloudTeachers ->
                        viewModelScope.launch {
                            cloudTeachers.forEach { teacher ->
                                repository.insertTeacher(teacher)
                            }
                        }
                    }

                    FirestoreService.fetchGradeRecords { cloudGrades ->
                        viewModelScope.launch {
                            cloudGrades.forEach { grade ->
                                repository.insertGrade(grade)
                            }
                        }
                    }

                    FirestoreService.fetchAttendanceRecords { cloudAttendance ->
                        viewModelScope.launch {
                            repository.insertAttendanceRecords(cloudAttendance)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("SchoolViewModel", "Cloud sync propagation error: ${e.message}")
            }
            delay(1500)
            _syncState.value = "Synced"
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            _lastSyncedTime.value = "at " + sdf.format(Date())
        }
    }

    // Create a new student profile
    fun addNewStudent(
        name: String,
        rollNo: String,
        gradeClass: String,
        contactNo: String,
        email: String,
        termFees: Double
    ) {
        viewModelScope.launch {
            val pendingPayment = termFees
            val newStudent = Student(
                name = name,
                rollNo = rollNo,
                gradeClass = gradeClass,
                contactNo = contactNo,
                email = email,
                totalFees = termFees,
                feesPaid = 0.0
            )
            val insertedId = repository.insertStudent(newStudent)
            val studentWithId = newStudent.copy(id = insertedId)
            
            // Sync with Firestore first
            FirestoreService.saveStudent(studentWithId)

            // Generate standard Tuition Fee invoice
            repository.insertInvoice(
                Invoice(
                    studentId = insertedId,
                    title = "Tuition Fees - Term 1",
                    amount = termFees,
                    issueDate = "2026-06-22",
                    dueDate = "2026-07-05",
                    status = "Pending"
                )
            )
            syncCloudData()
        }
    }

    // Update existing student details
    fun updateStudentDetails(student: Student) {
        viewModelScope.launch {
            repository.updateStudent(student)
            FirestoreService.saveStudent(student)
            syncCloudData()
        }
    }

    // Remove Student
    fun removeStudent(student: Student) {
        viewModelScope.launch {
            repository.deleteStudent(student)
            FirestoreService.deleteStudent(student)
            syncCloudData()
        }
    }

    // Remove Teacher
    fun removeTeacher(teacher: Teacher) {
        viewModelScope.launch {
            repository.deleteTeacher(teacher)
            FirestoreService.deleteTeacher(teacher)
            syncCloudData()
        }
    }

    // Delete Assignment
    fun deleteAssignment(assignment: Assignment) {
        viewModelScope.launch {
            repository.deleteAssignment(assignment)
            syncCloudData()
        }
    }

    // Register a Teacher
    fun addNewTeacher(
        name: String,
        subject: String,
        contactNo: String,
        email: String,
        gradeClass: String
    ) {
        viewModelScope.launch {
            val newTeacher = Teacher(
                name = name,
                subject = subject,
                contactNo = contactNo,
                email = email,
                gradeClass = gradeClass
            )
            val insertedId = repository.insertTeacher(newTeacher)
            FirestoreService.saveTeacher(newTeacher.copy(id = insertedId))
            syncCloudData()
        }
    }

    // Add Assignment
    fun postAssignment(title: String, description: String, subject: String, dueDate: String, gradeClass: String) {
        viewModelScope.launch {
            repository.insertAssignment(
                Assignment(
                    title = title,
                    description = description,
                    subject = subject,
                    dueDate = dueDate,
                    gradeClass = gradeClass
                )
            )
            // Raise student alert
            addNotification(
                title = "New Assignment: $title",
                message = "Subject: $subject. Due by: $dueDate. Description: $description",
                type = "Assignment",
                targetRole = UserRole.STUDENT
            )
            syncCloudData()
        }
    }

    // Add Exam Marks / Report Grades
    fun addStudentGrade(studentId: Long, subject: String, examName: String, marksObtained: Double, maxMarks: Double) {
        viewModelScope.launch {
            val record = GradeRecord(
                studentId = studentId,
                subject = subject,
                examName = examName,
                marksObtained = marksObtained,
                maxMarks = maxMarks
            )
            val insertedId = repository.insertGrade(record)
            FirestoreService.saveGradeRecord(record.copy(id = insertedId))
            
            // Post notification alert for student
            val student = repository.getStudentById(studentId)
            val studentName = student?.name ?: "Student"
            addNotification(
                title = "Report Card Released: $subject ($examName)",
                message = "Your grade card has been published! Score: $marksObtained / $maxMarks marks.",
                type = "Grade",
                targetRole = UserRole.STUDENT,
                targetUserId = studentId
            )
            
            addNotification(
                title = "Student Marks Posted",
                message = "Marksheet entry created for $studentName in $subject - $examName.",
                type = "Notice",
                targetRole = UserRole.ADMIN
            )

            syncCloudData()
        }
    }

    // Simulated sandbox Payment Processing for Invoice
    fun processPaymentForInvoice(invoice: Invoice) {
        viewModelScope.launch {
            _syncState.value = "Processing Payment..."
            delay(1000)
            
            val updatedInvoice = invoice.copy(status = "Paid")
            repository.updateInvoice(updatedInvoice)

            // Update student's fee summary
            val studentId = invoice.studentId
            val student = repository.getStudentById(studentId)
            if (student != null) {
                val updatedStudent = student.copy(
                    feesPaid = student.feesPaid + invoice.amount
                )
                repository.updateStudent(updatedStudent)
                FirestoreService.saveStudent(updatedStudent)

                // --- Auto Receipt Generation ---
                val receiptNo = "REC-${System.currentTimeMillis() % 1000000}"
                val sdfDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                val receipt = FeeReceipt(
                    receiptNo = receiptNo,
                    schoolName = _schoolNameState.value,
                    studentName = student.name,
                    studentId = student.id,
                    studentClass = student.gradeClass,
                    studentRoll = student.rollNo,
                    invoiceTitle = invoice.title,
                    amountPaid = invoice.amount,
                    paymentDate = sdfDate.format(Date()),
                    paymentStatus = "SUCCESS"
                )
                _lastGeneratedReceipt.value = receipt
                
                // Raise alerts for both student and admin roles
                addNotification(
                    title = "Fee Payment Processed",
                    message = "Official receipt $receiptNo generated: USD ${invoice.amount} paid successfully for ${invoice.title}.",
                    type = "Receipt",
                    targetRole = UserRole.STUDENT,
                    targetUserId = student.id
                )
                addNotification(
                    title = "New School SaaS Revenue Captured",
                    message = "Student ${student.name} fully cleared USD ${invoice.amount} for invoice: \"${invoice.title}\".",
                    type = "Fee Paid",
                    targetRole = UserRole.ADMIN
                )
            }
            
            _syncState.value = "Synced"
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            _lastSyncedTime.value = "at " + sdf.format(Date())
        }
    }

    // Batch Record Attendance for a class
    fun saveAttendanceSession(dateStr: String, attendanceMap: Map<Long, Boolean>) {
        viewModelScope.launch {
            _syncState.value = "Saving Attendance..."
            val records = attendanceMap.map { (studentId, isPresent) ->
                AttendanceRecord(
                    studentId = studentId,
                    dateString = dateStr,
                    isPresent = isPresent
                )
            }
            repository.insertAttendanceRecords(records)
            delay(500)
            
            try {
                // Fetch and sync the newly stored records to Firestore
                val savedRecords = repository.getAttendanceForDate(dateStr).first()
                FirestoreService.saveAttendanceRecords(savedRecords)
            } catch (e: Exception) {
                Log.e("SchoolViewModel", "Failed syncing attendance session: ${e.message}")
            }

            _syncState.value = "Synced"
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            _lastSyncedTime.value = "at " + sdf.format(Date())
        }
    }

    private val _schoolNameState = MutableStateFlow("Springdale International Academy")
    val schoolNameState: StateFlow<String> = _schoolNameState.asStateFlow()

    fun loadSchoolName(context: android.content.Context) {
        val sp = context.getSharedPreferences("edu_school_config", android.content.Context.MODE_PRIVATE)
        _schoolNameState.value = sp.getString("school_name", "Springdale International Academy") ?: "Springdale International Academy"
    }

    fun updateSchoolName(context: android.content.Context, newName: String) {
        val sp = context.getSharedPreferences("edu_school_config", android.content.Context.MODE_PRIVATE)
        sp.edit().putString("school_name", newName).apply()
        _schoolNameState.value = newName
        addNotification(
            title = "School Profile Updated",
            message = "Institutional profile modified to $newName successfully.",
            type = "System",
            targetRole = UserRole.ADMIN
        )
    }

    fun clearAllDatabaseRecords() {
        viewModelScope.launch {
            _syncState.value = "Clearing Database..."
            repository.clearAllData()
            delay(500)
            _syncState.value = "Database Cleared"
            _selectedStudentId.value = null
            addNotification(
                title = "Database Clean Slate",
                message = "All students, teachers, assignments, grades, and invoice data have been wiped from this device's storage.",
                type = "System",
                targetRole = UserRole.ADMIN
            )
        }
    }

    fun restoreDemoTemplateData() {
        viewModelScope.launch {
            _syncState.value = "Restoring Demo Data..."
            repository.seedMockDataForced()
            delay(500)
            _syncState.value = "Demo Data Restored"
            _selectedStudentId.value = null
            addNotification(
                title = "Demo Template Restored",
                message = "The pre-populated test data and assignments have been reloaded successfully.",
                type = "System",
                targetRole = UserRole.ADMIN
            )
        }
    }
}

class SchoolViewModelFactory(private val repository: SchoolRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SchoolViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SchoolViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
