package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class SchoolRepository(private val schoolDao: SchoolDao) {

    val allStudents: Flow<List<Student>> = schoolDao.getAllStudents()
    val allTeachers: Flow<List<Teacher>> = schoolDao.getAllTeachers()
    val allAssignments: Flow<List<Assignment>> = schoolDao.getAllAssignments()
    val allInvoices: Flow<List<Invoice>> = schoolDao.getAllInvoices()
    val allGrades: Flow<List<GradeRecord>> = schoolDao.getAllGrades()
    val allAttendanceRecords: Flow<List<AttendanceRecord>> = schoolDao.getAllAttendanceRecords()

    fun getStudentsByClass(gradeClass: String): Flow<List<Student>> =
        schoolDao.getStudentsByClass(gradeClass)

    fun getAssignmentsByClass(gradeClass: String): Flow<List<Assignment>> =
        schoolDao.getAssignmentsByClass(gradeClass)

    fun getInvoicesForStudent(studentId: Long): Flow<List<Invoice>> =
        schoolDao.getInvoicesForStudent(studentId)

    fun getGradesForStudent(studentId: Long): Flow<List<GradeRecord>> =
        schoolDao.getGradesForStudent(studentId)

    fun getAttendanceForDate(dateString: String): Flow<List<AttendanceRecord>> =
        schoolDao.getAttendanceForDate(dateString)

    fun getAttendanceForStudent(studentId: Long): Flow<List<AttendanceRecord>> =
        schoolDao.getAttendanceForStudent(studentId)

    suspend fun getStudentById(id: Long): Student? =
        schoolDao.getStudentById(id)

    suspend fun insertStudent(student: Student): Long =
        schoolDao.insertStudent(student)

    suspend fun updateStudent(student: Student) {
        schoolDao.updateStudent(student)
    }

    suspend fun deleteStudent(student: Student) {
        schoolDao.deleteStudent(student)
    }

    suspend fun insertTeacher(teacher: Teacher): Long =
        schoolDao.insertTeacher(teacher)

    suspend fun deleteTeacher(teacher: Teacher) =
        schoolDao.deleteTeacher(teacher)

    suspend fun insertAttendanceRecord(record: AttendanceRecord) {
        schoolDao.insertAttendanceRecord(record)
    }

    suspend fun insertAttendanceRecords(records: List<AttendanceRecord>) {
        schoolDao.insertAttendanceRecords(records)
    }

    suspend fun insertAssignment(assignment: Assignment): Long =
        schoolDao.insertAssignment(assignment)

    suspend fun deleteAssignment(assignment: Assignment) =
        schoolDao.deleteAssignment(assignment)

    suspend fun insertGrade(grade: GradeRecord): Long =
        schoolDao.insertGrade(grade)

    suspend fun deleteGrade(grade: GradeRecord) =
        schoolDao.deleteGrade(grade)

    suspend fun insertInvoice(invoice: Invoice): Long =
        schoolDao.insertInvoice(invoice)

    suspend fun updateInvoice(invoice: Invoice) {
        schoolDao.updateInvoice(invoice)
    }

    suspend fun deleteInvoice(invoice: Invoice) =
        schoolDao.deleteInvoice(invoice)

    // Pre-populates database with beautiful, realistic SaaS data if empty
    suspend fun seedMockDataIfEmpty() {
        val currentStudents = allStudents.first()
        if (currentStudents.isEmpty()) {
            val studentIds = mutableListOf<Long>()
            
            // Seed Students
            val mockedStudents = listOf(
                Student(name = "Aarav Sharma", rollNo = "101", gradeClass = "Class 10-A", contactNo = "+91 98765 43210", email = "aarav.sharma@eduhub.com", totalFees = 1500.0, feesPaid = 1500.0),
                Student(name = "Jane Watson", rollNo = "102", gradeClass = "Class 10-A", contactNo = "+1 555-0199", email = "jane.w@eduhub.com", totalFees = 1500.0, feesPaid = 500.0),
                Student(name = "Chloe Miller", rollNo = "103", gradeClass = "Class 10-B", contactNo = "+1 555-0182", email = "chloe.m@eduhub.com", totalFees = 1500.0, feesPaid = 1500.0),
                Student(name = "Maximilian Keller", rollNo = "104", gradeClass = "Class 10-A", contactNo = "+49 170 123456", email = "max.keller@eduhub.com", totalFees = 1600.0, feesPaid = 0.0),
                Student(name = "Sneha Patel", rollNo = "105", gradeClass = "Class 11-A", contactNo = "+91 91234 56789", email = "sneha.p@eduhub.com", totalFees = 1800.0, feesPaid = 1800.0),
                Student(name = "Liam Carter", rollNo = "106", gradeClass = "Class 11-B", contactNo = "+1 555-0143", email = "liam.carter@eduhub.com", totalFees = 1800.0, feesPaid = 900.0),
                Student(name = "Kaito Takahashi", rollNo = "107", gradeClass = "Class 12-A", contactNo = "+81 90 1234 5678", email = "kaito.t@eduhub.com", totalFees = 2000.0, feesPaid = 2000.0),
                Student(name = "Sophia Dubois", rollNo = "108", gradeClass = "Class 12-A", contactNo = "+33 6 1234 5678", email = "sophia.d@eduhub.com", totalFees = 2000.0, feesPaid = 1000.0)
            )

            for (stud in mockedStudents) {
                val id = insertStudent(stud)
                studentIds.add(id)
            }

            // Seed Teachers
            val mockedTeachers = listOf(
                Teacher(name = "Mr. Andrew Hargreeves", subject = "Mathematics", contactNo = "+1 555-0101", email = "andrew.h@eduhub.com", gradeClass = "Class 10-A"),
                Teacher(name = "Mrs. Sarah Jenkins", subject = "Physics", contactNo = "+1 555-0102", email = "sarah.j@eduhub.com", gradeClass = "Class 10-B"),
                Teacher(name = "Dr. Evelyn Foster", subject = "Chemistry", contactNo = "+1 555-0103", email = "evelyn.f@eduhub.com", gradeClass = "Class 11-A"),
                Teacher(name = "Prof. Robert Langdon", subject = "History", contactNo = "+1 555-0104", email = "robert.l@eduhub.com", gradeClass = "Class 12-A")
            )

            for (teacher in mockedTeachers) {
                insertTeacher(teacher)
            }

            // Seed Invoices
            if (studentIds.size >= 8) {
                // Aarav (id index 0) - Fully Paid
                insertInvoice(Invoice(studentId = studentIds[0], title = "Tuition Fees - Term 1", amount = 1000.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
                insertInvoice(Invoice(studentId = studentIds[0], title = "Annual Science Lab Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
                insertInvoice(Invoice(studentId = studentIds[0], title = "Sports Membership", amount = 200.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))

                // Jane (id index 1) - Partially Paid (1 paid, 2 outstanding)
                insertInvoice(Invoice(studentId = studentIds[1], title = "Tuition Fees - Term 1", amount = 1000.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Pending"))
                insertInvoice(Invoice(studentId = studentIds[1], title = "Annual Science Lab Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Pending"))
                insertInvoice(Invoice(studentId = studentIds[1], title = "Sports Membership", amount = 200.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))

                // Chloe (id index 2) - Fully Paid
                insertInvoice(Invoice(studentId = studentIds[2], title = "Tuition Fees - Term 1", amount = 1000.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
                insertInvoice(Invoice(studentId = studentIds[2], title = "Library Annual Card", amount = 150.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
                insertInvoice(Invoice(studentId = studentIds[2], title = "Quarterly Bus Transport", amount = 350.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))

                // Maximilian (id index 3) - Overdue Dues
                insertInvoice(Invoice(studentId = studentIds[3], title = "Tuition Fees - Term 1", amount = 1000.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Overdue"))
                insertInvoice(Invoice(studentId = studentIds[3], title = "Annual Science Lab Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Overdue"))
                insertInvoice(Invoice(studentId = studentIds[3], title = "Quarterly Bus Transport", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Overdue"))

                // Sneha (id index 4) - Paid
                insertInvoice(Invoice(studentId = studentIds[4], title = "Tuition Fees - Term 1", amount = 1200.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
                insertInvoice(Invoice(studentId = studentIds[4], title = "Annual Science Lab Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
                insertInvoice(Invoice(studentId = studentIds[4], title = "Computer Lab Club Dues", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))

                // Liam (id index 5) - Partially Paid
                insertInvoice(Invoice(studentId = studentIds[5], title = "Tuition Fees - Term 1", amount = 1200.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Pending"))
                insertInvoice(Invoice(studentId = studentIds[5], title = "Computer Lab Club Dues", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
                insertInvoice(Invoice(studentId = studentIds[5], title = "Gymnasium Annual Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Pending"))
            }

            // Seed Assignments
            val mockedAssignments = listOf(
                Assignment(title = "Calculus Integration Practice", description = "Solve chapter 5 questions 1 to 15. Show step-by-step logic detailing derivatives integration rules.", subject = "Mathematics", dueDate = "2026-06-25", gradeClass = "Class 10-A"),
                Assignment(title = "Electromagnetic Induction Report", description = "Draft a 500-word laboratory report explaining Faraday's Law with diagrams of basic electromagnet configurations.", subject = "Physics", dueDate = "2026-06-28", gradeClass = "Class 10-A"),
                Assignment(title = "Organic Carbon Chains", description = "Write structures and name the first 10 alkanes, alkenes, and alkynes in systematic IUPAC naming rules.", subject = "Chemistry", dueDate = "2026-06-29", gradeClass = "Class 10-B"),
                Assignment(title = "French Revolution Analysis", description = "Identify the key socio-economic triggers resulting in the Storming of the Bastille. Max 3 pages.", subject = "History", dueDate = "2026-07-02", gradeClass = "Class 12-A")
            )

            for (assignment in mockedAssignments) {
                insertAssignment(assignment)
            }

            // Seed Grades for Aarav and Jane
            if (studentIds.size >= 2) {
                insertGrade(GradeRecord(studentId = studentIds[0], subject = "Mathematics", examName = "Mid-Term Exam", marksObtained = 95.0, maxMarks = 100.0))
                insertGrade(GradeRecord(studentId = studentIds[0], subject = "Physics", examName = "Mid-Term Exam", marksObtained = 88.0, maxMarks = 100.0))
                insertGrade(GradeRecord(studentId = studentIds[0], subject = "Chemistry", examName = "Mid-Term Exam", marksObtained = 92.0, maxMarks = 100.0))

                insertGrade(GradeRecord(studentId = studentIds[1], subject = "Mathematics", examName = "Mid-Term Exam", marksObtained = 76.0, maxMarks = 100.0))
                insertGrade(GradeRecord(studentId = studentIds[1], subject = "Physics", examName = "Mid-Term Exam", marksObtained = 82.0, maxMarks = 100.0))
            }

            // Seed Attendance for June 15 to June 19 2026
            val days = listOf("2026-06-15", "2026-06-16", "2026-06-17", "2026-06-18", "2026-06-19")
            for (day in days) {
                for (sId in studentIds) {
                    // Seed attendance with 90% presence chance
                    val present = (Math.random() < 0.90)
                    insertAttendanceRecord(AttendanceRecord(studentId = sId, dateString = day, isPresent = present))
                }
            }
        }
    }

    suspend fun clearAllData() {
        schoolDao.clearStudents()
        schoolDao.clearTeachers()
        schoolDao.clearAttendance()
        schoolDao.clearAssignments()
        schoolDao.clearGrades()
        schoolDao.clearInvoices()
    }

    suspend fun seedMockDataForced() {
        clearAllData()
        // Now force seeding by bypassing the isNotEmpty check - we can copy the inner logic of seedMockDataIfEmpty or just insert
        val studentIds = mutableListOf<Long>()
        
        val mockedStudents = listOf(
            Student(name = "Aarav Sharma", rollNo = "101", gradeClass = "Class 10-A", contactNo = "+91 98765 43210", email = "aarav.sharma@eduhub.com", totalFees = 1500.0, feesPaid = 1500.0),
            Student(name = "Jane Watson", rollNo = "102", gradeClass = "Class 10-A", contactNo = "+1 555-0199", email = "jane.w@eduhub.com", totalFees = 1500.0, feesPaid = 500.0),
            Student(name = "Chloe Miller", rollNo = "103", gradeClass = "Class 10-B", contactNo = "+1 555-0182", email = "chloe.m@eduhub.com", totalFees = 1500.0, feesPaid = 1500.0),
            Student(name = "Maximilian Keller", rollNo = "104", gradeClass = "Class 10-A", contactNo = "+49 170 123456", email = "max.keller@eduhub.com", totalFees = 1600.0, feesPaid = 0.0),
            Student(name = "Sneha Patel", rollNo = "105", gradeClass = "Class 11-A", contactNo = "+91 91234 56789", email = "sneha.p@eduhub.com", totalFees = 1800.0, feesPaid = 1800.0),
            Student(name = "Liam Carter", rollNo = "106", gradeClass = "Class 11-B", contactNo = "+1 555-0143", email = "liam.carter@eduhub.com", totalFees = 1800.0, feesPaid = 900.0),
            Student(name = "Kaito Takahashi", rollNo = "107", gradeClass = "Class 12-A", contactNo = "+81 90 1234 5678", email = "kaito.t@eduhub.com", totalFees = 2000.0, feesPaid = 2000.0),
            Student(name = "Sophia Dubois", rollNo = "108", gradeClass = "Class 12-A", contactNo = "+33 6 1234 5678", email = "sophia.d@eduhub.com", totalFees = 2000.0, feesPaid = 1000.0)
        )

        for (stud in mockedStudents) {
            val id = insertStudent(stud)
            studentIds.add(id)
        }

        val mockedTeachers = listOf(
            Teacher(name = "Mr. Andrew Hargreeves", subject = "Mathematics", contactNo = "+1 555-0101", email = "andrew.h@eduhub.com", gradeClass = "Class 10-A"),
            Teacher(name = "Mrs. Sarah Jenkins", subject = "Physics", contactNo = "+1 555-0102", email = "sarah.j@eduhub.com", gradeClass = "Class 10-B"),
            Teacher(name = "Dr. Evelyn Foster", subject = "Chemistry", contactNo = "+1 555-0103", email = "evelyn.f@eduhub.com", gradeClass = "Class 11-A"),
            Teacher(name = "Prof. Robert Langdon", subject = "History", contactNo = "+1 555-0104", email = "robert.l@eduhub.com", gradeClass = "Class 12-A")
        )

        for (teacher in mockedTeachers) {
            insertTeacher(teacher)
        }

        if (studentIds.size >= 8) {
            insertInvoice(Invoice(studentId = studentIds[0], title = "Tuition Fees - Term 1", amount = 1000.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
            insertInvoice(Invoice(studentId = studentIds[0], title = "Annual Science Lab Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
            insertInvoice(Invoice(studentId = studentIds[0], title = "Sports Membership", amount = 200.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))

            insertInvoice(Invoice(studentId = studentIds[1], title = "Tuition Fees - Term 1", amount = 1000.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Pending"))
            insertInvoice(Invoice(studentId = studentIds[1], title = "Annual Science Lab Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Pending"))
            insertInvoice(Invoice(studentId = studentIds[1], title = "Sports Membership", amount = 200.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))

            insertInvoice(Invoice(studentId = studentIds[2], title = "Tuition Fees - Term 1", amount = 1000.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
            insertInvoice(Invoice(studentId = studentIds[2], title = "Library Annual Card", amount = 150.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
            insertInvoice(Invoice(studentId = studentIds[2], title = "Quarterly Bus Transport", amount = 350.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))

            insertInvoice(Invoice(studentId = studentIds[3], title = "Tuition Fees - Term 1", amount = 1000.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Overdue"))
            insertInvoice(Invoice(studentId = studentIds[3], title = "Annual Science Lab Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Overdue"))
            insertInvoice(Invoice(studentId = studentIds[3], title = "Quarterly Bus Transport", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Overdue"))

            insertInvoice(Invoice(studentId = studentIds[4], title = "Tuition Fees - Term 1", amount = 1200.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
            insertInvoice(Invoice(studentId = studentIds[4], title = "Annual Science Lab Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
            insertInvoice(Invoice(studentId = studentIds[4], title = "Computer Lab Club Dues", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))

            insertInvoice(Invoice(studentId = studentIds[5], title = "Tuition Fees - Term 1", amount = 1200.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Pending"))
            insertInvoice(Invoice(studentId = studentIds[5], title = "Computer Lab Club Dues", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Paid"))
            insertInvoice(Invoice(studentId = studentIds[5], title = "Gymnasium Annual Fee", amount = 300.0, issueDate = "2026-05-01", dueDate = "2026-05-15", status = "Pending"))
        }

        val mockedAssignments = listOf(
            Assignment(title = "Calculus Integration Practice", description = "Solve chapter 5 questions 1 to 15. Show step-by-step logic detailing derivatives integration rules.", subject = "Mathematics", dueDate = "2026-06-25", gradeClass = "Class 10-A"),
            Assignment(title = "Electromagnetic Induction Report", description = "Draft a 500-word laboratory report explaining Faraday's Law with diagrams of basic electromagnet configurations.", subject = "Physics", dueDate = "2026-06-28", gradeClass = "Class 10-A"),
            Assignment(title = "Organic Carbon Chains", description = "Write structures and name the first 10 alkanes, alkenes, and alkynes in systematic IUPAC naming rules.", subject = "Chemistry", dueDate = "2026-06-29", gradeClass = "Class 10-B"),
            Assignment(title = "French Revolution Analysis", description = "Identify the key socio-economic triggers resulting in the Storming of the Bastille. Max 3 pages.", subject = "History", dueDate = "2026-07-02", gradeClass = "Class 12-A")
        )

        for (assignment in mockedAssignments) {
            insertAssignment(assignment)
        }

        if (studentIds.size >= 2) {
            insertGrade(GradeRecord(studentId = studentIds[0], subject = "Mathematics", examName = "Mid-Term Exam", marksObtained = 95.0, maxMarks = 100.0))
            insertGrade(GradeRecord(studentId = studentIds[0], subject = "Physics", examName = "Mid-Term Exam", marksObtained = 88.0, maxMarks = 100.0))
            insertGrade(GradeRecord(studentId = studentIds[0], subject = "Chemistry", examName = "Mid-Term Exam", marksObtained = 92.0, maxMarks = 100.0))

            insertGrade(GradeRecord(studentId = studentIds[1], subject = "Mathematics", examName = "Mid-Term Exam", marksObtained = 76.0, maxMarks = 100.0))
            insertGrade(GradeRecord(studentId = studentIds[1], subject = "Physics", examName = "Mid-Term Exam", marksObtained = 82.0, maxMarks = 100.0))
        }

        val days = listOf("2026-06-15", "2026-06-16", "2026-06-17", "2026-06-18", "2026-06-19")
        for (day in days) {
            for (sId in studentIds) {
                val present = (Math.random() < 0.90)
                insertAttendanceRecord(AttendanceRecord(studentId = sId, dateString = day, isPresent = present))
            }
        }
    }
}
