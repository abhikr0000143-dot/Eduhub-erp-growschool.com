package com.example.data

import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

// Extension conversion functions for fully clean, type-safe Firestore dynamic mapping
fun Student.toMap(): Map<String, Any> {
    return mapOf(
        "id" to id,
        "name" to name,
        "rollNo" to rollNo,
        "gradeClass" to gradeClass,
        "contactNo" to contactNo,
        "email" to email,
        "totalFees" to totalFees,
        "feesPaid" to feesPaid
    )
}

fun Map<String, Any>.toStudent(): Student {
    return Student(
        id = (this["id"] as? Number)?.toLong() ?: 0L,
        name = this["name"] as? String ?: "",
        rollNo = this["rollNo"] as? String ?: "",
        gradeClass = this["gradeClass"] as? String ?: "",
        contactNo = this["contactNo"] as? String ?: "",
        email = this["email"] as? String ?: "",
        totalFees = (this["totalFees"] as? Number)?.toDouble() ?: 0.0,
        feesPaid = (this["feesPaid"] as? Number)?.toDouble() ?: 0.0
    )
}

fun Teacher.toMap(): Map<String, Any> {
    return mapOf(
        "id" to id,
        "name" to name,
        "subject" to subject,
        "contactNo" to contactNo,
        "email" to email,
        "gradeClass" to gradeClass
    )
}

fun Map<String, Any>.toTeacher(): Teacher {
    return Teacher(
        id = (this["id"] as? Number)?.toLong() ?: 0L,
        name = this["name"] as? String ?: "",
        subject = this["subject"] as? String ?: "",
        contactNo = this["contactNo"] as? String ?: "",
        email = this["email"] as? String ?: "",
        gradeClass = this["gradeClass"] as? String ?: ""
    )
}

fun AttendanceRecord.toMap(): Map<String, Any> {
    return mapOf(
        "id" to id,
        "studentId" to studentId,
        "dateString" to dateString,
        "isPresent" to isPresent
    )
}

fun Map<String, Any>.toAttendanceRecord(): AttendanceRecord {
    return AttendanceRecord(
        id = (this["id"] as? Number)?.toLong() ?: 0L,
        studentId = (this["studentId"] as? Number)?.toLong() ?: 0L,
        dateString = this["dateString"] as? String ?: "",
        isPresent = this["isPresent"] as? Boolean ?: false
    )
}

fun GradeRecord.toMap(): Map<String, Any> {
    return mapOf(
        "id" to id,
        "studentId" to studentId,
        "subject" to subject,
        "examName" to examName,
        "marksObtained" to marksObtained,
        "maxMarks" to maxMarks
    )
}

fun Map<String, Any>.toGradeRecord(): GradeRecord {
    return GradeRecord(
        id = (this["id"] as? Number)?.toLong() ?: 0L,
        studentId = (this["studentId"] as? Number)?.toLong() ?: 0L,
        subject = this["subject"] as? String ?: "",
        examName = this["examName"] as? String ?: "",
        marksObtained = (this["marksObtained"] as? Number)?.toDouble() ?: 0.0,
        maxMarks = (this["maxMarks"] as? Number)?.toDouble() ?: 0.0
    )
}

/**
 * Resilient Cloud sync manager connecting modern local Room DAO DB state with Google Firestore database collections.
 * Leverages high fidelity safe-checks to bypass connection dropouts gracefully.
 */
object FirestoreService {
    private const val TAG = "FirestoreService"
    private var firestore: FirebaseFirestore? = null
    var isFirestoreAvailable = false
        private set

    init {
        try {
            FirebaseApp.getInstance()
            firestore = FirebaseFirestore.getInstance()
            isFirestoreAvailable = true
            Log.d(TAG, "Firestore Service initialized successfully.")
        } catch (e: Exception) {
            isFirestoreAvailable = false
            Log.w(TAG, "Real Firestore not detected. Relying fully on local DB layer. ${e.localizedMessage}")
        }
    }

    // --- Students Sync ---
    fun saveStudent(student: Student, onComplete: (Boolean) -> Unit = {}) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("students")
                .document(student.id.toString())
                .set(student.toMap())
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.i(TAG, "Saved Student ${student.name} to Firestore")
                    } else {
                        Log.w(TAG, "Failed saving Student ${student.name}: ${task.exception?.message}")
                    }
                    onComplete(task.isSuccessful)
                }
        } else {
            onComplete(true)
        }
    }

    fun deleteStudent(student: Student, onComplete: (Boolean) -> Unit = {}) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("students")
                .document(student.id.toString())
                .delete()
                .addOnCompleteListener { task ->
                    onComplete(task.isSuccessful)
                }
        } else {
            onComplete(true)
        }
    }

    fun fetchStudents(onResult: (List<Student>) -> Unit) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("students")
                .get()
                .addOnSuccessListener { result ->
                    val list = result.documents.mapNotNull { doc ->
                        doc.data?.toStudent()
                    }
                    onResult(list)
                }
                .addOnFailureListener {
                    onResult(emptyList())
                }
        } else {
            onResult(emptyList())
        }
    }

    // --- Teachers Sync ---
    fun saveTeacher(teacher: Teacher, onComplete: (Boolean) -> Unit = {}) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("teachers")
                .document(teacher.id.toString())
                .set(teacher.toMap())
                .addOnCompleteListener { task ->
                    onComplete(task.isSuccessful)
                }
        } else {
            onComplete(true)
        }
    }

    fun deleteTeacher(teacher: Teacher, onComplete: (Boolean) -> Unit = {}) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("teachers")
                .document(teacher.id.toString())
                .delete()
                .addOnCompleteListener { task ->
                    onComplete(task.isSuccessful)
                }
        } else {
            onComplete(true)
        }
    }

    fun fetchTeachers(onResult: (List<Teacher>) -> Unit) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("teachers")
                .get()
                .addOnSuccessListener { result ->
                    val list = result.documents.mapNotNull { doc ->
                        doc.data?.toTeacher()
                    }
                    onResult(list)
                }
                .addOnFailureListener {
                    onResult(emptyList())
                }
        } else {
            onResult(emptyList())
        }
    }

    // --- Attendance Sync ---
    fun saveAttendanceRecord(record: AttendanceRecord, onComplete: (Boolean) -> Unit = {}) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("attendance")
                .document(record.id.toString())
                .set(record.toMap())
                .addOnCompleteListener { task ->
                    onComplete(task.isSuccessful)
                }
        } else {
            onComplete(true)
        }
    }

    fun saveAttendanceRecords(records: List<AttendanceRecord>, onComplete: (Boolean) -> Unit = {}) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            val batch = db.batch()
            records.forEach { record ->
                val ref = db.collection("attendance").document(record.id.toString())
                batch.set(ref, record.toMap())
            }
            batch.commit().addOnCompleteListener { task ->
                onComplete(task.isSuccessful)
            }
        } else {
            onComplete(true)
        }
    }

    fun fetchAttendanceRecords(onResult: (List<AttendanceRecord>) -> Unit) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("attendance")
                .get()
                .addOnSuccessListener { result ->
                    val list = result.documents.mapNotNull { doc ->
                        doc.data?.toAttendanceRecord()
                    }
                    onResult(list)
                }
                .addOnFailureListener {
                    onResult(emptyList())
                }
        } else {
            onResult(emptyList())
        }
    }

    // --- Grades Sync ---
    fun saveGradeRecord(record: GradeRecord, onComplete: (Boolean) -> Unit = {}) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("grades")
                .document(record.id.toString())
                .set(record.toMap())
                .addOnCompleteListener { task ->
                    onComplete(task.isSuccessful)
                }
        } else {
            onComplete(true)
        }
    }

    fun deleteGradeRecord(record: GradeRecord, onComplete: (Boolean) -> Unit = {}) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("grades")
                .document(record.id.toString())
                .delete()
                .addOnCompleteListener { task ->
                    onComplete(task.isSuccessful)
                }
        } else {
            onComplete(true)
        }
    }

    fun fetchGradeRecords(onResult: (List<GradeRecord>) -> Unit) {
        val db = firestore
        if (isFirestoreAvailable && db != null) {
            db.collection("grades")
                .get()
                .addOnSuccessListener { result ->
                    val list = result.documents.mapNotNull { doc ->
                        doc.data?.toGradeRecord()
                    }
                    onResult(list)
                }
                .addOnFailureListener {
                    onResult(emptyList())
                }
        } else {
            onResult(emptyList())
        }
    }
}
