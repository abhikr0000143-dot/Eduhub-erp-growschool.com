package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.example.data.SchoolDatabase
import com.example.data.SchoolRepository
import com.example.ui.EduHubERPMainArea
import com.example.ui.SchoolViewModel
import com.example.ui.SchoolViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Room Database, Repository, and ViewModel
    val database = Room.databaseBuilder(
        applicationContext,
        SchoolDatabase::class.java,
        "school_database"
    ).build()
    
    val repository = SchoolRepository(database.schoolDao())
    val factory = SchoolViewModelFactory(repository)
    val viewModel = ViewModelProvider(this, factory)[SchoolViewModel::class.java]

    // Restore active role session on cold launch
    viewModel.checkPersistedSession(applicationContext)
    viewModel.loadSchoolName(applicationContext)

    setContent {
      MyApplicationTheme {
        EduHubERPMainArea(viewModel)
      }
    }
  }
}
